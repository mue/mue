(self["webpackChunkmue"] = self["webpackChunkmue"] || []).push([[325],{

/***/ 3325:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ Weather; }
});

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(2137);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__(6610);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/createClass.js
var createClass = __webpack_require__(5991);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/inherits.js
var inherits = __webpack_require__(379);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js
var possibleConstructorReturn = __webpack_require__(6070);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__(7608);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__(7757);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
// EXTERNAL MODULE: ./src/modules/helpers/eventbus.js
var eventbus = __webpack_require__(9620);
// EXTERNAL MODULE: ./node_modules/weather-icons-react/index.js
var weather_icons_react = __webpack_require__(1900);
// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
;// CONCATENATED MODULE: ./src/components/widgets/weather/WeatherIcon.jsx
var _WiDaySunny, _WiNightClear, _WiDayCloudy, _WiNightCloudy, _WiCloud, _WiCloudy, _WiDayShowers, _WiNightShowers, _WiRain, _WiThunderstorm, _WiSnow, _WiFog;



function WeatherIcon(props) {
  var icon; // props.name is the openweathermap icon name, see https://openweathermap.org/weather-conditions

  switch (props.name) {
    case '01d':
      icon = _WiDaySunny || (_WiDaySunny = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiDaySunny */.Rq0, {}));
      break;

    case '01n':
      icon = _WiNightClear || (_WiNightClear = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiNightClear */.KCd, {}));
      break;

    case '02d':
      icon = _WiDayCloudy || (_WiDayCloudy = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiDayCloudy */.GW5, {}));
      break;

    case '02n':
      icon = _WiNightCloudy || (_WiNightCloudy = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiNightCloudy */.tNw, {}));
      break;

    case '03d':
    case '03n':
      icon = _WiCloud || (_WiCloud = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiCloud */.DF0, {}));
      break;

    case '04d':
    case '04n':
      icon = _WiCloudy || (_WiCloudy = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiCloudy */.l64, {}));
      break;

    case '09d':
      icon = _WiDayShowers || (_WiDayShowers = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiDayShowers */.B8, {}));
      break;

    case '09n':
      icon = _WiNightShowers || (_WiNightShowers = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiNightShowers */.jBV, {}));
      break;

    case '10d':
    case '10n':
      icon = _WiRain || (_WiRain = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiRain */.IC8, {}));
      break;

    case '11d':
    case '11n':
      icon = _WiThunderstorm || (_WiThunderstorm = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiThunderstorm */.YSA, {}));
      break;

    case '13d':
    case '13n':
      icon = _WiSnow || (_WiSnow = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiSnow */.GPo, {}));
      break;

    case '50d':
    case '50n':
      icon = _WiFog || (_WiFog = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiFog */.QGj, {}));
      break;

    default:
      icon = null;
      break;
  }

  return icon;
}
;// CONCATENATED MODULE: ./src/components/widgets/weather/WindDirectionIcon.jsx
var _WiDirectionUp, _WiDirectionUpLeft, _WiDirectionLeft, _WiDirectionDownLeft, _WiDirectionDown, _WiDirectionDownRight, _WiDirectionRight, _WiDirectionUpRight;



function WindDirectionIcon(props) {
  var icon; // convert the number openweathermap gives us to closest direction or something

  var directions = ['North', 'North-West', 'West', 'South-West', 'South', 'South-East', 'East', 'North-East'];
  var direction = directions[Math.round(((props.degrees %= 360) < 0 ? props.degrees + 360 : props.degrees) / 45) % 8];

  switch (direction) {
    case 'North':
      icon = _WiDirectionUp || (_WiDirectionUp = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiDirectionUp */.Xpc, {}));
      break;

    case 'North-West':
      icon = _WiDirectionUpLeft || (_WiDirectionUpLeft = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiDirectionUpLeft */.vt, {}));
      break;

    case 'West':
      icon = _WiDirectionLeft || (_WiDirectionLeft = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiDirectionLeft */.VU, {}));
      break;

    case 'South-West':
      icon = _WiDirectionDownLeft || (_WiDirectionDownLeft = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiDirectionDownLeft */._R8, {}));
      break;

    case 'South':
      icon = _WiDirectionDown || (_WiDirectionDown = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiDirectionDown */.N5v, {}));
      break;

    case 'South-East':
      icon = _WiDirectionDownRight || (_WiDirectionDownRight = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiDirectionDownRight */.Hbi, {}));
      break;

    case 'East':
      icon = _WiDirectionRight || (_WiDirectionRight = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiDirectionRight */.HI7, {}));
      break;

    case 'North-East':
      icon = _WiDirectionUpRight || (_WiDirectionUpRight = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiDirectionUpRight */.$5p, {}));
      break;

    default:
      icon = null;
      break;
  }

  return icon;
}
;// CONCATENATED MODULE: ./src/components/widgets/weather/Weather.jsx







var _br, _br2, _br3, _br4, _br5, _WiHumidity, _br6, _WiWindy, _span, _br7, Weather_WiCloud, _br8, _br9, _WiBarometer, _span2, _br10;



function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }











var Weather = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(Weather, _React$PureComponent);

  var _super = _createSuper(Weather);

  function Weather() {
    var _this;

    (0,classCallCheck/* default */.Z)(this, Weather);

    _this = _super.call(this);
    _this.state = {
      location: localStorage.getItem('location') || 'London',
      icon: '',
      temp_text: '',
      weather: {
        temp: '',
        description: '',
        temp_min: '',
        temp_max: '',
        humidity: '',
        wind_speed: '',
        wind_degrees: '',
        cloudiness: '',
        visibility: '',
        pressure: ''
      }
    };
    return _this;
  }

  (0,createClass/* default */.Z)(Weather, [{
    key: "getWeather",
    value: function () {
      var _getWeather = (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee() {
        var data, temp, temp_min, temp_max, temp_text;
        return regenerator_default().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!(localStorage.getItem('offlineMode') === 'true')) {
                  _context.next = 2;
                  break;
                }

                return _context.abrupt("return", null);

              case 2:
                data = {
                  weather: [{
                    description: this.state.weather.description,
                    icon: this.state.icon
                  }],
                  main: {
                    temp: this.state.weather.original_temp,
                    temp_min: this.state.weather.original_temp_min,
                    temp_max: this.state.weather.original_temp_max,
                    humidity: this.state.weather.humidity,
                    pressure: this.state.weather.pressure
                  },
                  visibility: this.state.weather.visibility,
                  wind: {
                    speed: this.state.weather.wind_speed,
                    deg: this.state.weather.wind_degrees
                  },
                  clouds: {
                    all: this.state.weather.cloudiness
                  }
                };

                if (this.state.weather.temp) {
                  _context.next = 9;
                  break;
                }

                _context.next = 6;
                return fetch(window.constants.WEATHER_URL + "/current?city=".concat(this.state.location, "&lang=").concat(localStorage.getItem('language')));

              case 6:
                _context.next = 8;
                return _context.sent.json();

              case 8:
                data = _context.sent;

              case 9:
                if (!(data.cod === '404')) {
                  _context.next = 11;
                  break;
                }

                return _context.abrupt("return", this.setState({
                  location: window.language.widgets.weather.not_found
                }));

              case 11:
                temp = data.main.temp;
                temp_min = data.main.temp_min;
                temp_max = data.main.temp_max;
                temp_text = 'K';
                _context.t0 = localStorage.getItem('tempformat');
                _context.next = _context.t0 === 'celsius' ? 18 : _context.t0 === 'fahrenheit' ? 23 : 28;
                break;

              case 18:
                temp = temp - 273.15;
                temp_min = temp_min - 273.15;
                temp_max = temp_max - 273.15;
                temp_text = '°C';
                return _context.abrupt("break", 29);

              case 23:
                temp = (temp - 273.15) * 1.8 + 32;
                temp_min = (temp_min - 273.15) * 1.8 + 32;
                temp_max = (temp_max - 273.15) * 1.8 + 32;
                temp_text = '°F';
                return _context.abrupt("break", 29);

              case 28:
                return _context.abrupt("break", 29);

              case 29:
                this.setState({
                  icon: data.weather[0].icon,
                  temp_text: temp_text,
                  weather: {
                    temp: Math.round(temp),
                    description: data.weather[0].description,
                    temp_min: Math.round(temp_min),
                    temp_max: Math.round(temp_max),
                    humidity: data.main.humidity,
                    wind_speed: data.wind.speed,
                    wind_degrees: data.wind.deg,
                    cloudiness: data.clouds.all,
                    visibility: data.visibility,
                    pressure: data.main.pressure,
                    original_temp: data.main.temp,
                    original_temp_min: data.main.temp_min,
                    original_temp_max: data.main.temp_max
                  }
                });
                document.querySelector('.weather svg').style.fontSize = "".concat(0.95 * Number((localStorage.getItem('zoomWeather') || 100) / 100), "em");

              case 31:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function getWeather() {
        return _getWeather.apply(this, arguments);
      }

      return getWeather;
    }()
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      eventbus/* default.on */.Z.on('refresh', function (data) {
        if (data === 'weather') {
          _this2.getWeather();

          document.querySelector('.weather').style.fontSize = "".concat(Number((localStorage.getItem('zoomWeather') || 100) / 100), "em");
          document.querySelector('.weather svg').style.fontSize = "".concat(0.95 * Number((localStorage.getItem('zoomWeather') || 100) / 100), "em");
        }
      });
      document.querySelector('.weather').style.fontSize = "".concat(Number((localStorage.getItem('zoomWeather') || 100) / 100), "em");
      this.getWeather();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      eventbus/* default.remove */.Z.remove('refresh');
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var enabled = function enabled(setting) {
        return localStorage.getItem(setting) === 'true';
      };

      if (enabled('offlineMode')) {
        return null;
      }

      if (this.state.location === window.language.widgets.weather.not_found) {
        return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
          className: "weather",
          children: /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
            className: "loc",
            children: this.state.location
          })
        });
      }

      var minmax = function minmax() {
        var mintemp = enabled('mintemp');
        var maxtemp = enabled('maxtemp');

        if (!mintemp && !maxtemp) {
          return null;
        } else if (mintemp && !maxtemp) {
          return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
            children: [_br || (_br = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), _this3.state.weather.temp_min + _this3.state.temp_text]
          });
        } else if (maxtemp && !mintemp) {
          return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
            children: [_br2 || (_br2 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), _this3.state.weather.temp_max + _this3.state.temp_text]
          });
        } else {
          return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
            children: [_br3 || (_br3 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), _this3.state.weather.temp_min + _this3.state.temp_text, " ", _this3.state.weather.temp_max + _this3.state.temp_text]
          });
        }
      };

      return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "weather",
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)(WeatherIcon, {
          name: this.state.icon
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
          children: this.state.weather.temp + this.state.temp_text
        }), enabled('weatherdescription') ? /*#__PURE__*/(0,jsx_runtime.jsxs)("span", {
          className: "loc",
          style: {
            'textTransform': 'capitalize'
          },
          children: [_br4 || (_br4 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), this.state.weather.description]
        }) : null, /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
          className: "minmax",
          children: minmax()
        }), enabled('humidity') ? /*#__PURE__*/(0,jsx_runtime.jsxs)("span", {
          className: "loc",
          children: [_br5 || (_br5 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), _WiHumidity || (_WiHumidity = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiHumidity */.$2C, {})), this.state.weather.humidity, "%"]
        }) : null, enabled('windspeed') ? /*#__PURE__*/(0,jsx_runtime.jsxs)("span", {
          className: "loc",
          children: [_br6 || (_br6 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), _WiWindy || (_WiWindy = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiWindy */.jYk, {})), this.state.weather.wind_speed, _span || (_span = /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
            className: "minmax",
            children: " m/s"
          })), " ", enabled('windDirection') ? /*#__PURE__*/(0,jsx_runtime.jsx)(WindDirectionIcon, {
            degrees: this.state.weather.wind_degrees
          }) : null]
        }) : null, enabled('cloudiness') ? /*#__PURE__*/(0,jsx_runtime.jsxs)("span", {
          className: "loc",
          children: [_br7 || (_br7 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), Weather_WiCloud || (Weather_WiCloud = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiCloud */.DF0, {})), this.state.weather.cloudiness, "%"]
        }) : null, enabled('visibility') ? /*#__PURE__*/(0,jsx_runtime.jsxs)("span", {
          className: "loc",
          children: [_br8 || (_br8 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), this.state.weather.visibility, " ", window.language.widgets.weather.meters]
        }) : null, enabled('atmosphericpressure') ? /*#__PURE__*/(0,jsx_runtime.jsxs)("span", {
          className: "loc",
          children: [_br9 || (_br9 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), _WiBarometer || (_WiBarometer = /*#__PURE__*/(0,jsx_runtime.jsx)(weather_icons_react/* WiBarometer */.eQ_, {})), this.state.weather.pressure, _span2 || (_span2 = /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
            className: "minmax",
            children: " hPa"
          }))]
        }) : null, _br10 || (_br10 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), enabled('showlocation') ? /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
          className: "loc",
          children: this.state.location
        }) : null]
      });
    }
  }]);

  return Weather;
}(react.PureComponent);



/***/ })

}]);