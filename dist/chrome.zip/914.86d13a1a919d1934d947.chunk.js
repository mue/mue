(self["webpackChunkmue"] = self["webpackChunkmue"] || []).push([[914],{

/***/ 155:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ Lightbox; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);



function Lightbox(props) {
  window.analytics.postEvent('modal', 'Opened lightbox');
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
      className: "closeModal",
      onClick: props.modalClose,
      children: "\xD7"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
      src: props.img,
      className: "lightboximg",
      draggable: false,
      alt: "Item screenshot"
    })]
  });
}

/***/ }),

/***/ 6414:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ Dropdown; }
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6610);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5991);
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3349);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(379);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6070);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7608);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6156);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7294);
/* harmony import */ var _modules_helpers_eventbus__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9620);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5893);








function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }







var Dropdown = /*#__PURE__*/function (_React$PureComponent) {
  (0,_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z)(Dropdown, _React$PureComponent);

  var _super = _createSuper(Dropdown);

  function Dropdown(props) {
    var _this;

    (0,_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z)(this, Dropdown);

    _this = _super.call(this, props);

    (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)((0,_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z)(_this), "onChange", function (e) {
      var value = e.target.value;

      if (value === window.language.modals.main.loading) {
        return;
      }

      window.analytics.postEvent('setting', "".concat(_this.props.name, " from ").concat(_this.state.value, " to ").concat(value));

      _this.setState({
        value: value,
        title: e.target[e.target.selectedIndex].text
      });

      localStorage.setItem(_this.props.name, value);

      if (_this.props.onChange) {
        _this.props.onChange(value);
      }

      if (_this.props.element) {
        if (!document.querySelector(_this.props.element)) {
          document.querySelector('.reminder-info').style.display = 'block';
          return localStorage.setItem('showReminder', true);
        }
      }

      _modules_helpers_eventbus__WEBPACK_IMPORTED_MODULE_8__/* .default.dispatch */ .Z.dispatch('refresh', _this.props.category);
    });

    _this.state = {
      value: localStorage.getItem(_this.props.name) || '',
      title: ''
    };
    return _this;
  }

  (0,_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z)(Dropdown, [{
    key: "getLabel",
    value: function getLabel() {
      return this.props.label ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("label", {
        children: this.props.label
      }) : null;
    }
  }, {
    key: "componentDidMount",
    value: // todo: find a better way to do this
    function componentDidMount() {
      var element = document.getElementById(this.props.name);
      this.setState({
        title: element[element.selectedIndex].text
      });
    }
  }, {
    key: "render",
    value: function render() {
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
        children: [this.getLabel(), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("select", {
          id: this.props.name,
          value: this.state.value,
          onChange: this.onChange,
          style: {
            width: "".concat(8 * this.state.title.length + 50, "px")
          },
          children: this.props.children
        })]
      });
    }
  }]);

  return Dropdown;
}(react__WEBPACK_IMPORTED_MODULE_2__.PureComponent);



/***/ }),

/***/ 9469:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ FileUpload; }
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6610);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5991);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(379);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6070);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7608);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7294);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2132);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5893);






function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }





var FileUpload = /*#__PURE__*/function (_React$PureComponent) {
  (0,_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z)(FileUpload, _React$PureComponent);

  var _super = _createSuper(FileUpload);

  function FileUpload() {
    (0,_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z)(this, FileUpload);

    return _super.apply(this, arguments);
  }

  (0,_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)(FileUpload, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this = this;

      document.getElementById(this.props.id).onchange = function (e) {
        var reader = new FileReader();
        var file = e.target.files[0];

        if (_this.props.type === 'settings') {
          reader.readAsText(file, 'UTF-8');
        } else {
          // background upload
          if (file.size > 2000000) {
            return (0,react_toastify__WEBPACK_IMPORTED_MODULE_7__/* .toast */ .Am)(window.language.modals.main.file_upload_error);
          }

          reader.readAsDataURL(file);
        }

        reader.addEventListener('load', function (e) {
          _this.props.loadFunction(e);
        });
      };
    }
  }, {
    key: "render",
    value: function render() {
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("input", {
        id: this.props.id,
        type: "file",
        style: {
          display: 'none'
        },
        accept: this.props.accept
      });
    }
  }]);

  return FileUpload;
}(react__WEBPACK_IMPORTED_MODULE_2__.PureComponent);



/***/ }),

/***/ 8914:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ Settings; }
});

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(2137);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__(6610);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/createClass.js
var createClass = __webpack_require__(5991);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/inherits.js
var inherits = __webpack_require__(379);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js
var possibleConstructorReturn = __webpack_require__(6070);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__(7608);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__(7757);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
// EXTERNAL MODULE: ./src/components/helpers/tooltip/Tooltip.jsx
var Tooltip = __webpack_require__(4783);
// EXTERNAL MODULE: ./node_modules/@material-ui/icons/Email.js
var Email = __webpack_require__(3781);
// EXTERNAL MODULE: ./node_modules/@material-ui/icons/Twitter.js
var Twitter = __webpack_require__(4704);
// EXTERNAL MODULE: ./node_modules/@material-ui/icons/Forum.js
var Forum = __webpack_require__(5515);
// EXTERNAL MODULE: ./node_modules/@material-ui/icons/Instagram.js
var Instagram = __webpack_require__(4363);
// EXTERNAL MODULE: ./node_modules/@material-ui/icons/Facebook.js
var Facebook = __webpack_require__(3792);
// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/About.jsx







var _img, _a, _a2, _a3, _a4, _a5, _a6, _p, _a7, _a8, _a9, _a10;



function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }












var other_contributors = __webpack_require__(1668);

var About = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(About, _React$PureComponent);

  var _super = _createSuper(About);

  function About() {
    var _this;

    (0,classCallCheck/* default */.Z)(this, About);

    _this = _super.call(this);
    _this.state = {
      contributors: [],
      sponsors: [],
      other_contributors: [],
      photographers: window.language.modals.main.loading,
      update: window.language.modals.main.settings.sections.about.version.checking_update,
      loading: window.language.modals.main.loading
    };
    _this.language = window.language.modals.main.settings.sections.about;
    _this.controller = new AbortController();
    return _this;
  }

  (0,createClass/* default */.Z)(About, [{
    key: "getGitHubData",
    value: function () {
      var _getGitHubData = (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee() {
        var contributors, sponsors, photographers, versionData, newVersion, updateMsg;
        return regenerator_default().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.prev = 0;
                _context.next = 3;
                return fetch(window.constants.GITHUB_URL + '/repos/mue/mue/releases', {
                  signal: this.controller.signal
                });

              case 3:
                _context.next = 5;
                return _context.sent.json();

              case 5:
                versionData = _context.sent;
                _context.next = 8;
                return fetch(window.constants.GITHUB_URL + '/repos/mue/mue/contributors', {
                  signal: this.controller.signal
                });

              case 8:
                _context.next = 10;
                return _context.sent.json();

              case 10:
                contributors = _context.sent;
                _context.next = 13;
                return fetch(window.constants.SPONSORS_URL + '/list', {
                  signal: this.controller.signal
                });

              case 13:
                _context.next = 15;
                return _context.sent.json();

              case 15:
                sponsors = _context.sent.sponsors;
                _context.next = 18;
                return fetch(window.constants.API_URL + '/images/photographers', {
                  signal: this.controller.signal
                });

              case 18:
                _context.next = 20;
                return _context.sent.json();

              case 20:
                photographers = _context.sent;
                _context.next = 28;
                break;

              case 23:
                _context.prev = 23;
                _context.t0 = _context["catch"](0);

                if (!(this.controller.signal.aborted === true)) {
                  _context.next = 27;
                  break;
                }

                return _context.abrupt("return");

              case 27:
                return _context.abrupt("return", this.setState({
                  update: this.language.version.error.title,
                  loading: this.language.version.error.description
                }));

              case 28:
                if (!(this.controller.signal.aborted === true)) {
                  _context.next = 30;
                  break;
                }

                return _context.abrupt("return");

              case 30:
                newVersion = versionData[0].tag_name;
                updateMsg = this.language.version.no_update;

                if (Number(window.constants.VERSION.replaceAll('.', '')) < Number(newVersion.replaceAll('.', ''))) {
                  updateMsg = "".concat(this.language.version.update_available, ": ").concat(newVersion);
                }

                this.setState({
                  contributors: contributors.filter(function (contributor) {
                    return !contributor.login.includes('bot');
                  }),
                  sponsors: sponsors,
                  update: updateMsg,
                  other_contributors: other_contributors,
                  photographers: photographers.sort().join(', '),
                  loading: null
                });

              case 34:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[0, 23]]);
      }));

      function getGitHubData() {
        return _getGitHubData.apply(this, arguments);
      }

      return getGitHubData;
    }()
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      if (navigator.onLine === false || localStorage.getItem('offlineMode') === 'true') {
        this.setState({
          update: this.language.version.offline_mode,
          loading: window.language.modals.main.marketplace.offline.description
        });
        return;
      }

      this.getGitHubData();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      // stop making requests
      this.controller.abort();
    }
  }, {
    key: "render",
    value: function render() {
      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h2", {
          children: this.language.title
        }), _img || (_img = /*#__PURE__*/(0,jsx_runtime.jsx)("img", {
          draggable: "false",
          className: "aboutLogo",
          src: "./././icons/logo_horizontal.png",
          alt: "Mue logo"
        })), /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          children: [this.language.copyright, " 2018-", new Date().getFullYear(), " ", _a || (_a = /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
            href: "https://github.com/mue/mue/graphs/contributors",
            className: "aboutLink",
            target: "_blank",
            rel: "noopener noreferrer",
            children: "The Mue Authors"
          })), " (BSD-3 License)"]
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          children: [this.language.version.title, " ", window.constants.VERSION, " (", this.state.update, ")"]
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: this.language.contact_us
        }), _a2 || (_a2 = /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
          href: "mailto:hello@muetab.com",
          className: "aboutIcon",
          target: "_blank",
          rel: "noopener noreferrer",
          children: /*#__PURE__*/(0,jsx_runtime.jsx)(Email/* default */.Z, {})
        })), _a3 || (_a3 = /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
          href: "https://twitter.com/getmue",
          className: "aboutIcon",
          target: "_blank",
          rel: "noopener noreferrer",
          children: /*#__PURE__*/(0,jsx_runtime.jsx)(Twitter/* default */.Z, {})
        })), _a4 || (_a4 = /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
          href: "https://instagram.com/mue.tab",
          className: "aboutIcon",
          target: "_blank",
          rel: "noopener noreferrer",
          children: /*#__PURE__*/(0,jsx_runtime.jsx)(Instagram/* default */.Z, {})
        })), _a5 || (_a5 = /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
          href: "https://facebook.com/muetab",
          className: "aboutIcon",
          target: "_blank",
          rel: "noopener noreferrer",
          children: /*#__PURE__*/(0,jsx_runtime.jsx)(Facebook/* default */.Z, {})
        })), _a6 || (_a6 = /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
          href: "https://discord.gg/zv8C9F8",
          className: "aboutIcon",
          target: "_blank",
          rel: "noopener noreferrer",
          children: /*#__PURE__*/(0,jsx_runtime.jsx)(Forum/* default */.Z, {})
        })), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: this.language.support_mue
        }), _p || (_p = /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          children: [/*#__PURE__*/(0,jsx_runtime.jsx)("a", {
            href: "https://github.com/sponsors/davidjcralph",
            className: "aboutLink",
            target: "_blank",
            rel: "noopener noreferrer",
            children: "GitHub Sponsors"
          }), "\xA0 \u2022 \xA0", /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
            href: "https://ko-fi.com/davidjcralph",
            className: "aboutLink",
            target: "_blank",
            rel: "noopener noreferrer",
            children: "Ko-Fi"
          }), "\xA0 \u2022 \xA0", /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
            href: "https://patreon.com/davidjcralph",
            className: "aboutLink",
            target: "_blank",
            rel: "noopener noreferrer",
            children: "Patreon"
          })]
        })), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: this.language.resources_used.title
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          children: [_a7 || (_a7 = /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
            href: "https://www.pexels.com",
            className: "aboutLink",
            target: "_blank",
            rel: "noopener noreferrer",
            children: "Pexels"
          })), ", ", _a8 || (_a8 = /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
            href: "https://unsplash.com",
            className: "aboutLink",
            target: "_blank",
            rel: "noopener noreferrer",
            children: "Unsplash"
          })), " (", this.language.resources_used.bg_images, ")"]
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          children: [_a9 || (_a9 = /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
            href: "https://fonts.google.com/icons?selected=Material+Icons",
            className: "aboutLink",
            target: "_blank",
            rel: "noopener noreferrer",
            children: "Google Fonts"
          })), " (", this.language.resources_used.pin_icon, ")"]
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          children: [_a10 || (_a10 = /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
            href: "https://undraw.co",
            className: "aboutLink",
            target: "_blank",
            rel: "noopener noreferrer",
            children: "Undraw"
          })), " (", this.language.resources_used.welcome_img, ")"]
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: this.language.contributors
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("p", {
          children: this.state.loading
        }), this.state.contributors.map(function (item) {
          return /*#__PURE__*/(0,jsx_runtime.jsx)(Tooltip/* default */.Z, {
            title: item.login,
            children: /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
              href: 'https://github.com/' + item.login,
              target: "_blank",
              rel: "noopener noreferrer",
              children: /*#__PURE__*/(0,jsx_runtime.jsx)("img", {
                draggable: "false",
                className: "abouticon",
                src: item.avatar_url + '&size=128',
                alt: item.login
              })
            })
          }, item.login);
        }), // for those who contributed without opening a pull request
        this.state.other_contributors.map(function (item) {
          return /*#__PURE__*/(0,jsx_runtime.jsx)(Tooltip/* default */.Z, {
            title: item.login,
            children: /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
              href: 'https://github.com/' + item.login,
              target: "_blank",
              rel: "noopener noreferrer",
              children: /*#__PURE__*/(0,jsx_runtime.jsx)("img", {
                draggable: "false",
                className: "abouticon",
                src: item.avatar_url + '&size=128',
                alt: item.login
              })
            })
          }, item.login);
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: this.language.supporters
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("p", {
          children: this.state.loading
        }), this.state.sponsors.map(function (item) {
          return /*#__PURE__*/(0,jsx_runtime.jsx)(Tooltip/* default */.Z, {
            title: item.handle,
            children: /*#__PURE__*/(0,jsx_runtime.jsx)("a", {
              href: item.profile,
              target: "_blank",
              rel: "noopener noreferrer",
              children: /*#__PURE__*/(0,jsx_runtime.jsx)("img", {
                draggable: "false",
                className: "abouticon",
                src: item.avatar + '&size=128',
                alt: item.handle
              })
            })
          }, item.handle);
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: this.language.photographers
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("p", {
          children: this.state.photographers
        })]
      });
    }
  }]);

  return About;
}(react.PureComponent);


// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js
var assertThisInitialized = __webpack_require__(3349);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/defineProperty.js
var defineProperty = __webpack_require__(6156);
// EXTERNAL MODULE: ./src/modules/helpers/eventbus.js
var eventbus = __webpack_require__(9620);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/Radio/Radio.js + 4 modules
var Radio_Radio = __webpack_require__(74);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/RadioGroup/RadioGroup.js + 1 modules
var RadioGroup = __webpack_require__(7162);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/FormControlLabel/FormControlLabel.js + 1 modules
var FormControlLabel = __webpack_require__(6546);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/FormControl/FormControl.js + 1 modules
var FormControl = __webpack_require__(6893);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/FormLabel/FormLabel.js + 1 modules
var FormLabel = __webpack_require__(5238);
;// CONCATENATED MODULE: ./src/components/modals/main/settings/Radio.jsx








var _RadioUI;

function Radio_createSuper(Derived) { var hasNativeReflectConstruct = Radio_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Radio_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }











var Radio = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(Radio, _React$PureComponent);

  var _super = Radio_createSuper(Radio);

  function Radio(props) {
    var _this;

    (0,classCallCheck/* default */.Z)(this, Radio);

    _this = _super.call(this, props);

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "handleChange", function (e) {
      var value = e.target.value;

      if (value === 'loading') {
        return;
      }

      localStorage.setItem(_this.props.name, value);

      _this.setState({
        value: value
      });

      window.analytics.postEvent('setting', "".concat(_this.props.name, " from ").concat(_this.state.value, " to ").concat(value));

      if (_this.props.element) {
        if (!document.querySelector(_this.props.element)) {
          document.querySelector('.reminder-info').style.display = 'block';
          return localStorage.setItem('showReminder', true);
        }
      }

      eventbus/* default.dispatch */.Z.dispatch('refresh', _this.props.category);
    });

    _this.state = {
      value: localStorage.getItem(_this.props.name)
    };
    return _this;
  }

  (0,createClass/* default */.Z)(Radio, [{
    key: "render",
    value: function render() {
      return /*#__PURE__*/(0,jsx_runtime.jsxs)(FormControl/* default */.Z, {
        component: "fieldset",
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)(FormLabel/* default */.Z, {
          className: this.props.smallTitle ? 'radio-title-small' : 'radio-title',
          component: "legend",
          children: this.props.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(RadioGroup/* default */.Z, {
          "aria-label": this.props.name,
          name: this.props.name,
          onChange: this.handleChange,
          value: this.state.value,
          children: this.props.options.map(function (option) {
            return /*#__PURE__*/(0,jsx_runtime.jsx)(FormControlLabel/* default */.Z, {
              value: option.value,
              control: _RadioUI || (_RadioUI = /*#__PURE__*/(0,jsx_runtime.jsx)(Radio_Radio/* default */.Z, {})),
              label: option.name
            }, option.name);
          })
        })]
      });
    }
  }]);

  return Radio;
}(react.PureComponent);


;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/Language.jsx







var _Radio;



function Language_createSuper(Derived) { var hasNativeReflectConstruct = Language_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Language_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }







var languages = __webpack_require__(6584);

var BackgroundSettings = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(BackgroundSettings, _React$PureComponent);

  var _super = Language_createSuper(BackgroundSettings);

  function BackgroundSettings() {
    var _this;

    (0,classCallCheck/* default */.Z)(this, BackgroundSettings);

    _this = _super.call(this);
    _this.state = {
      quoteLanguages: [{
        name: window.language.modals.main.loading,
        value: 'loading'
      }]
    };
    _this.controller = new AbortController();
    return _this;
  }

  (0,createClass/* default */.Z)(BackgroundSettings, [{
    key: "getQuoteLanguages",
    value: function () {
      var _getQuoteLanguages = (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee() {
        var data, array;
        return regenerator_default().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return fetch(window.constants.API_URL + '/quotes/languages', {
                  signal: this.controller.signal
                });

              case 2:
                _context.next = 4;
                return _context.sent.json();

              case 4:
                data = _context.sent;

                if (!(this.controller.signal.aborted === true)) {
                  _context.next = 7;
                  break;
                }

                return _context.abrupt("return");

              case 7:
                array = [];
                data.forEach(function (item) {
                  array.push({
                    name: item,
                    value: item
                  });
                });
                this.setState({
                  quoteLanguages: array
                });

              case 10:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function getQuoteLanguages() {
        return _getQuoteLanguages.apply(this, arguments);
      }

      return getQuoteLanguages;
    }()
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      if (navigator.onLine === false || localStorage.getItem('offlineMode') === 'true') {
        return this.setState({
          quoteLanguages: [{
            name: window.language.modals.main.marketplace.offline.description,
            value: 'loading'
          }]
        });
      }

      this.getQuoteLanguages();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      // stop making requests
      this.controller.abort();
    }
  }, {
    key: "render",
    value: function render() {
      var language = window.language.modals.main.settings.sections.language;
      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h2", {
          children: language.title
        }), _Radio || (_Radio = /*#__PURE__*/(0,jsx_runtime.jsx)(Radio, {
          name: "language",
          options: languages,
          element: ".language"
        })), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: language.quote
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Radio, {
          name: "quotelanguage",
          options: this.state.quoteLanguages,
          category: "quote"
        })]
      });
    }
  }]);

  return BackgroundSettings;
}(react.PureComponent);


// EXTERNAL MODULE: ./src/components/modals/main/settings/Dropdown.jsx
var Dropdown = __webpack_require__(6414);
// EXTERNAL MODULE: ./src/modules/helpers/settings.js
var settings = __webpack_require__(7185);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/Checkbox/Checkbox.js + 3 modules
var Checkbox_Checkbox = __webpack_require__(3258);
;// CONCATENATED MODULE: ./src/components/modals/main/settings/Checkbox.jsx








var _span, _span2, _br;

function Checkbox_createSuper(Derived) { var hasNativeReflectConstruct = Checkbox_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Checkbox_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }










var Checkbox = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(Checkbox, _React$PureComponent);

  var _super = Checkbox_createSuper(Checkbox);

  function Checkbox(props) {
    var _this;

    (0,classCallCheck/* default */.Z)(this, Checkbox);

    _this = _super.call(this, props);

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "handleChange", function () {
      settings/* default.setItem */.Z.setItem(_this.props.name);

      _this.setState({
        checked: _this.state.checked === true ? false : true
      });

      window.analytics.postEvent('setting', "".concat(_this.props.name, " ").concat(_this.state.checked === true ? 'enabled' : 'disabled'));

      if (_this.props.element) {
        if (!document.querySelector(_this.props.element)) {
          document.querySelector('.reminder-info').style.display = 'block';
          return localStorage.setItem('showReminder', true);
        }
      }

      eventbus/* default.dispatch */.Z.dispatch('refresh', _this.props.category);
    });

    _this.state = {
      checked: localStorage.getItem(_this.props.name) === 'true'
    };
    return _this;
  }

  (0,createClass/* default */.Z)(Checkbox, [{
    key: "render",
    value: function render() {
      var text = this.props.text;

      if (this.props.newFeature) {
        text = /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
          children: [this.props.text, " ", _span || (_span = /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
            className: "newFeature",
            children: " NEW"
          }))]
        });
      } else if (this.props.betaFeature) {
        text = /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
          children: [this.props.text, " ", _span2 || (_span2 = /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
            className: "newFeature",
            children: " BETA"
          }))]
        });
      }

      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)(FormControlLabel/* default */.Z, {
          control: /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox_Checkbox/* default */.Z, {
            name: this.props.name,
            color: "primary",
            checked: this.state.checked,
            onChange: this.handleChange
          }),
          label: text
        }), _br || (_br = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {}))]
      });
    }
  }]);

  return Checkbox;
}(react.PureComponent);


// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/Switch/Switch.js
var Switch_Switch = __webpack_require__(9570);
;// CONCATENATED MODULE: ./src/components/modals/main/settings/Switch.jsx








var Switch_span, Switch_span2, Switch_br;

function Switch_createSuper(Derived) { var hasNativeReflectConstruct = Switch_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Switch_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }










var Switch = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(Switch, _React$PureComponent);

  var _super = Switch_createSuper(Switch);

  function Switch(props) {
    var _this;

    (0,classCallCheck/* default */.Z)(this, Switch);

    _this = _super.call(this, props);

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "handleChange", function () {
      settings/* default.setItem */.Z.setItem(_this.props.name);

      _this.setState({
        checked: _this.state.checked === true ? false : true
      });

      window.analytics.postEvent('setting', "".concat(_this.props.name, " ").concat(_this.state.checked === true ? 'enabled' : 'disabled'));

      if (_this.props.element) {
        if (!document.querySelector(_this.props.element)) {
          document.querySelector('.reminder-info').style.display = 'block';
          return localStorage.setItem('showReminder', true);
        }
      }

      eventbus/* default.dispatch */.Z.dispatch('refresh', _this.props.category);
    });

    _this.state = {
      checked: localStorage.getItem(_this.props.name) === 'true'
    };
    return _this;
  }

  (0,createClass/* default */.Z)(Switch, [{
    key: "render",
    value: function render() {
      var text = this.props.text;

      if (this.props.newFeature) {
        text = /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
          children: [this.props.text, " ", Switch_span || (Switch_span = /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
            className: "newFeature",
            children: " NEW"
          }))]
        });
      } else if (this.props.betaFeature) {
        text = /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
          children: [this.props.text, " ", Switch_span2 || (Switch_span2 = /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
            className: "newFeature",
            children: " BETA"
          }))]
        });
      }

      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)(FormControlLabel/* default */.Z, {
          control: /*#__PURE__*/(0,jsx_runtime.jsx)(Switch_Switch/* default */.Z, {
            name: this.props.name,
            color: "primary",
            checked: this.state.checked,
            onChange: this.handleChange
          }),
          label: text,
          labelPlacement: "start"
        }), Switch_br || (Switch_br = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {}))]
      });
    }
  }]);

  return Switch;
}(react.PureComponent);


// EXTERNAL MODULE: ./node_modules/react-toastify/dist/react-toastify.esm.js
var react_toastify_esm = __webpack_require__(2132);
;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/Search.jsx






var Search_br, _br2;

function Search_createSuper(Derived) { var hasNativeReflectConstruct = Search_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Search_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }












var searchEngines = __webpack_require__(1331);

var autocompleteProviders = __webpack_require__(3858);

var SearchSettings = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(SearchSettings, _React$PureComponent);

  var _super = Search_createSuper(SearchSettings);

  function SearchSettings() {
    var _this;

    (0,classCallCheck/* default */.Z)(this, SearchSettings);

    _this = _super.call(this);
    _this.state = {
      customEnabled: false,
      customDisplay: 'none',
      customValue: localStorage.getItem('customSearchEngine') || ''
    };
    _this.language = window.language.modals.main.settings;
    return _this;
  }

  (0,createClass/* default */.Z)(SearchSettings, [{
    key: "resetSearch",
    value: function resetSearch() {
      localStorage.removeItem('customSearchEngine');
      this.setState({
        customValue: ''
      });
      (0,react_toastify_esm/* toast */.Am)(window.language.modals.main.settings.toasts.reset);
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      if (localStorage.getItem('searchEngine') === 'custom') {
        this.setState({
          customDisplay: 'block',
          customEnabled: true
        });
      } else {
        localStorage.removeItem('customSearchEngine');
      }
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      if (this.state.customEnabled === true && this.state.customValue !== '') {
        localStorage.setItem('customSearchEngine', this.state.customValue);
      }

      eventbus/* default.dispatch */.Z.dispatch('refresh', 'search');
    }
  }, {
    key: "setSearchEngine",
    value: function setSearchEngine(input) {
      if (input === 'custom') {
        this.setState({
          customDisplay: 'block',
          customEnabled: true
        });
      } else {
        this.setState({
          customDisplay: 'none',
          customEnabled: false
        });
        localStorage.setItem('searchEngine', input);
      }

      eventbus/* default.dispatch */.Z.dispatch('refresh', 'search');
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var language = window.language.modals.main.settings;
      var search = language.sections.search;
      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h2", {
          children: search.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Switch, {
          name: "searchBar",
          text: language.enabled,
          category: "widgets"
        }), navigator.userAgent.includes('Chrome') && typeof InstallTrigger === 'undefined' ? /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "voiceSearch",
          text: search.voice_search,
          category: "search",
          element: ".other"
        }) : null, /*#__PURE__*/(0,jsx_runtime.jsxs)(Dropdown/* default */.Z, {
          label: search.search_engine,
          name: "searchEngine",
          onChange: function onChange(value) {
            return _this2.setSearchEngine(value);
          },
          children: [searchEngines.map(function (engine) {
            return /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
              value: engine.settingsName,
              children: engine.name
            }, engine.name);
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "custom",
            children: search.custom.split(' ')[0]
          })]
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("ul", {
          style: {
            display: this.state.customDisplay
          },
          children: [Search_br || (Search_br = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
            style: {
              'marginTop': '0px'
            },
            children: [search.custom, " ", /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
              className: "modalLink",
              onClick: function onClick() {
                return _this2.resetSearch();
              },
              children: language.buttons.reset
            })]
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("input", {
            type: "text",
            value: this.state.customValue,
            onInput: function onInput(e) {
              return _this2.setState({
                customValue: e.target.value
              });
            }
          })]
        }), _br2 || (_br2 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "autocomplete",
          text: search.autocomplete,
          category: "search",
          element: ".other"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Radio, {
          title: search.autocomplete_provider,
          options: autocompleteProviders,
          name: "autocompleteProvider",
          category: "search"
        })]
      });
    }
  }]);

  return SearchSettings;
}(react.PureComponent);


;// CONCATENATED MODULE: ./src/components/modals/main/settings/Text.jsx








function Text_createSuper(Derived) { var hasNativeReflectConstruct = Text_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Text_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }








var Text = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(Text, _React$PureComponent);

  var _super = Text_createSuper(Text);

  function Text(props) {
    var _this;

    (0,classCallCheck/* default */.Z)(this, Text);

    _this = _super.call(this, props);

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "handleChange", function (e) {
      var value = e.target.value; // Alex wanted font to work with montserrat and Montserrat, so I made it work

      if (_this.props.upperCaseFirst === true) {
        value = value.charAt(0).toUpperCase() + value.slice(1);
      }

      localStorage.setItem(_this.props.name, value);

      _this.setState({
        value: value
      });

      if (_this.props.element) {
        if (!document.querySelector(_this.props.element)) {
          document.querySelector('.reminder-info').style.display = 'block';
          return localStorage.setItem('showReminder', true);
        }
      }

      eventbus/* default.dispatch */.Z.dispatch('refresh', _this.props.category);
    });

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "resetItem", function () {
      _this.handleChange({
        target: {
          value: _this.props.default || ''
        }
      });

      (0,react_toastify_esm/* toast */.Am)(window.language.toasts.reset);
    });

    _this.state = {
      value: localStorage.getItem(_this.props.name) || ''
    };
    _this.language = window.language.modals.main.settings;
    return _this;
  }

  (0,createClass/* default */.Z)(Text, [{
    key: "render",
    value: function render() {
      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          children: [this.props.title, " ", /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
            className: "modalLink",
            onClick: this.resetItem,
            children: this.language.buttons.reset
          })]
        }), this.props.textarea === true ? /*#__PURE__*/(0,jsx_runtime.jsx)("textarea", {
          className: "settingsTextarea",
          spellCheck: false,
          value: this.state.value,
          onChange: this.handleChange
        }) : /*#__PURE__*/(0,jsx_runtime.jsx)("input", {
          type: "text",
          value: this.state.value,
          onChange: this.handleChange
        })]
      });
    }
  }]);

  return Text;
}(react.PureComponent);


;// CONCATENATED MODULE: ./src/components/modals/main/settings/Slider.jsx








function Slider_createSuper(Derived) { var hasNativeReflectConstruct = Slider_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Slider_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

// todo: find a better method to do width of number input







var Slider = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(Slider, _React$PureComponent);

  var _super = Slider_createSuper(Slider);

  function Slider(props) {
    var _this;

    (0,classCallCheck/* default */.Z)(this, Slider);

    _this = _super.call(this, props);

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "handleChange", function (e, text) {
      var value = e.target.value;

      if (text) {
        if (value === '') {
          return _this.setState({
            value: 0
          });
        }

        if (Number(value) > _this.props.max) {
          value = _this.props.max;
        }

        if (Number(value) < _this.props.min) {
          value = _this.props.min;
        }
      }

      localStorage.setItem(_this.props.name, value);

      _this.setState({
        value: value,
        numberWidth: (value.length + 1) * _this.widthCalculation
      });

      if (_this.props.element) {
        if (!document.querySelector(_this.props.element)) {
          document.querySelector('.reminder-info').style.display = 'block';
          return localStorage.setItem('showReminder', true);
        }
      }

      eventbus/* default.dispatch */.Z.dispatch('refresh', _this.props.category);
    });

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "resetItem", function () {
      _this.handleChange({
        target: {
          value: _this.props.default || ''
        }
      });

      (0,react_toastify_esm/* toast */.Am)(window.language.toasts.reset);
    });

    _this.state = {
      value: localStorage.getItem(_this.props.name) || _this.props.default,
      numberWidth: localStorage.getItem(_this.props.name) ? (localStorage.getItem(_this.props.name).length + 1) * (_this.props.toast === true ? 7.75 : 7) : 32
    };
    _this.language = window.language.modals.main.settings;
    _this.widthCalculation = _this.props.toast === true ? 7.75 : 7;
    return _this;
  }

  (0,createClass/* default */.Z)(Slider, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var text = /*#__PURE__*/(0,jsx_runtime.jsx)("input", {
        className: "sliderText",
        type: "number",
        min: this.props.min,
        max: this.props.max,
        onChange: function onChange(e) {
          return _this2.handleChange(e, 'text');
        },
        value: this.state.value,
        style: {
          width: this.state.numberWidth
        }
      });

      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          children: [this.props.title, " (", text, this.props.display, ") ", /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
            className: "modalLink",
            onClick: this.resetItem,
            children: this.language.buttons.reset
          })]
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("input", {
          className: "range",
          type: "range",
          min: this.props.min,
          max: this.props.max,
          step: this.props.step || 1,
          value: this.state.value,
          onChange: this.handleChange
        })]
      });
    }
  }]);

  return Slider;
}(react.PureComponent);


// EXTERNAL MODULE: ./node_modules/react-day-picker/DayPickerInput/index.js
var DayPickerInput = __webpack_require__(6733);
;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/Greeting.jsx








function Greeting_createSuper(Derived) { var hasNativeReflectConstruct = Greeting_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Greeting_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }












var GreetingSettings = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(GreetingSettings, _React$PureComponent);

  var _super = Greeting_createSuper(GreetingSettings);

  function GreetingSettings() {
    var _this;

    (0,classCallCheck/* default */.Z)(this, GreetingSettings);

    _this = _super.call(this);

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "changeDate", function (data) {
      localStorage.setItem('birthday', data);

      _this.setState({
        birthday: data
      });
    });

    _this.state = {
      birthday: new Date(localStorage.getItem('birthday')) || new Date()
    };
    _this.language = window.language.modals.main.settings;
    return _this;
  }

  (0,createClass/* default */.Z)(GreetingSettings, [{
    key: "render",
    value: function render() {
      var greeting = this.language.sections.greeting;
      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h2", {
          children: greeting.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Switch, {
          name: "greeting",
          text: this.language.enabled,
          category: "greeting",
          element: ".greeting"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "events",
          text: greeting.events,
          category: "greeting",
          element: ".greeting"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "defaultGreetingMessage",
          text: greeting.default,
          category: "greeting",
          element: ".greeting"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Text, {
          title: greeting.name,
          name: "greetingName",
          category: "greeting",
          element: ".greeting"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Slider, {
          title: window.language.modals.main.settings.sections.appearance.accessibility.widget_zoom,
          name: "zoomGreeting",
          min: "10",
          max: "400",
          default: "100",
          display: "%",
          category: "greeting",
          element: ".greeting"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: greeting.birthday
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Switch, {
          name: "birthdayenabled",
          text: this.language.enabled,
          category: "greeting",
          element: ".greeting"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "birthdayage",
          text: greeting.birthday_age,
          category: "greeting",
          element: ".greeting"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("p", {
          children: greeting.birthday_date
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(DayPickerInput.default, {
          onDayChange: this.changeDate,
          value: this.state.birthday
        })]
      });
    }
  }]);

  return GreetingSettings;
}(react.PureComponent);


;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/Time.jsx






var Time_br, Time_br2, _option, _option2, _option3, _br3, _br4, _br5;

function Time_createSuper(Derived) { var hasNativeReflectConstruct = Time_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Time_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }











var TimeSettings = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(TimeSettings, _React$PureComponent);

  var _super = Time_createSuper(TimeSettings);

  function TimeSettings() {
    var _this;

    (0,classCallCheck/* default */.Z)(this, TimeSettings);

    _this = _super.call(this);
    _this.state = {
      timeType: localStorage.getItem('timeType') || 'digital',
      dateType: localStorage.getItem('dateType') || 'long'
    };
    _this.language = window.language.modals.main.settings;
    return _this;
  }

  (0,createClass/* default */.Z)(TimeSettings, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var time = this.language.sections.time;
      var timeSettings;
      var digitalOptions = [{
        name: time.digital.twentyfourhour,
        value: 'twentyfourhour'
      }, {
        name: time.digital.twelvehour,
        value: 'twelvehour'
      }];

      var digitalSettings = /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: time.digital.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Radio, {
          title: time.format,
          name: "timeformat",
          options: digitalOptions,
          smallTitle: true,
          category: "clock",
          element: ".clock-container"
        }), Time_br || (Time_br = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "seconds",
          text: time.digital.seconds,
          category: "clock",
          element: ".clock-container"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "zero",
          text: time.digital.zero,
          category: "clock",
          element: ".clock-container"
        })]
      });

      var analogSettings = /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: time.analogue.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "secondHand",
          text: time.analogue.second_hand,
          category: "clock",
          element: ".clock-container"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "minuteHand",
          text: time.analogue.minute_hand,
          category: "clock",
          element: ".clock-container"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "hourHand",
          text: time.analogue.hour_hand,
          category: "clock",
          element: ".clock-container"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "hourMarks",
          text: time.analogue.hour_marks,
          category: "clock",
          element: ".clock-container"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "minuteMarks",
          text: time.analogue.minute_marks,
          category: "clock",
          element: ".clock-container"
        })]
      });

      switch (this.state.timeType) {
        case 'digital':
          timeSettings = digitalSettings;
          break;

        case 'analogue':
          timeSettings = analogSettings;
          break;

        default:
          timeSettings = null;
          break;
      }

      var dateSettings;

      var longSettings = /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "dayofweek",
          text: time.date.day_of_week,
          category: "date",
          element: ".date"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "datenth",
          text: time.date.datenth,
          category: "date",
          element: ".date"
        })]
      });

      var shortSettings = /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [Time_br2 || (Time_br2 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsxs)(Dropdown/* default */.Z, {
          label: time.date.short_format,
          name: "dateFormat",
          category: "date",
          element: ".date",
          children: [_option || (_option = /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "DMY",
            children: "DMY"
          })), _option2 || (_option2 = /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "MDY",
            children: "MDY"
          })), _option3 || (_option3 = /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "YMD",
            children: "YMD"
          }))]
        }), _br3 || (_br3 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), _br4 || (_br4 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsxs)(Dropdown/* default */.Z, {
          label: time.date.short_separator.title,
          name: "shortFormat",
          category: "date",
          element: ".date",
          children: [/*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "dots",
            children: time.date.short_separator.dots
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "dash",
            children: time.date.short_separator.dash
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "gaps",
            children: time.date.short_separator.gaps
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "slashes",
            children: time.date.short_separator.slashes
          })]
        })]
      });

      switch (this.state.dateType) {
        case 'short':
          dateSettings = shortSettings;
          break;

        case 'long':
          dateSettings = longSettings;
          break;

        default:
          break;
      }

      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h2", {
          children: time.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Switch, {
          name: "time",
          text: this.language.enabled,
          category: "clock",
          element: ".clock-container"
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)(Dropdown/* default */.Z, {
          label: time.type,
          name: "timeType",
          onChange: function onChange(value) {
            return _this2.setState({
              timeType: value
            });
          },
          category: "clock",
          element: ".clock-container",
          children: [/*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "digital",
            children: time.digital.title
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "analogue",
            children: time.analogue.title
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "percentageComplete",
            children: time.percentage_complete
          })]
        }), timeSettings, this.state.timeType !== 'analogue' ? /*#__PURE__*/(0,jsx_runtime.jsx)(Slider, {
          title: window.language.modals.main.settings.sections.appearance.accessibility.widget_zoom,
          name: "zoomClock",
          min: "10",
          max: "400",
          default: "100",
          display: "%",
          category: "clock",
          element: ".clock-container"
        }) : null, /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: time.date.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Switch, {
          name: "date",
          text: this.language.enabled,
          category: "date",
          element: ".date"
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)(Dropdown/* default */.Z, {
          label: time.type,
          name: "dateType",
          onChange: function onChange(value) {
            return _this2.setState({
              dateType: value
            });
          },
          category: "date",
          element: ".date",
          children: [/*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "long",
            children: time.date.type.long
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "short",
            children: time.date.type.short
          })]
        }), _br5 || (_br5 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "datezero",
          text: time.digital.zero,
          category: "date",
          element: ".date"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "weeknumber",
          text: time.date.week_number,
          category: "date",
          element: ".date"
        }), dateSettings, /*#__PURE__*/(0,jsx_runtime.jsx)(Slider, {
          title: window.language.modals.main.settings.sections.appearance.accessibility.widget_zoom,
          name: "zoomDate",
          min: "10",
          max: "400",
          default: "100",
          display: "%",
          category: "date",
          element: ".date"
        })]
      });
    }
  }]);

  return TimeSettings;
}(react.PureComponent);


;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/Quote.jsx








function Quote_createSuper(Derived) { var hasNativeReflectConstruct = Quote_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Quote_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }











var QuoteSettings = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(QuoteSettings, _React$PureComponent);

  var _super = Quote_createSuper(QuoteSettings);

  function QuoteSettings() {
    var _this;

    (0,classCallCheck/* default */.Z)(this, QuoteSettings);

    _this = _super.call(this);

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "marketplaceType", function () {
      if (localStorage.getItem('quote_packs')) {
        return /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
          value: "quote_pack",
          children: window.language.modals.main.navbar.marketplace
        });
      }
    });

    _this.state = {
      quoteType: localStorage.getItem('quoteType') || 'api'
    };
    return _this;
  }

  (0,createClass/* default */.Z)(QuoteSettings, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var quote = window.language.modals.main.settings.sections.quote;
      var quoteSettings;

      var customSettings = /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)(Text, {
          title: quote.custom,
          name: "customQuote",
          category: "quote",
          element: ".quotediv"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Text, {
          title: quote.custom_author,
          name: "customQuoteAuthor",
          category: "quote",
          element: ".quotediv"
        })]
      });

      switch (this.state.quoteType) {
        case 'custom':
          quoteSettings = customSettings;
          break;

        default:
          break;
      }

      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h2", {
          children: quote.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Switch, {
          name: "quote",
          text: window.language.modals.main.settings.enabled,
          category: "quote",
          element: ".quotediv"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "authorLink",
          text: quote.author_link,
          element: ".other"
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)(Dropdown/* default */.Z, {
          label: window.language.modals.main.settings.sections.background.type.title,
          name: "quoteType",
          onChange: function onChange(value) {
            return _this2.setState({
              quoteType: value
            });
          },
          category: "quote",
          children: [this.marketplaceType(), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "api",
            children: window.language.modals.main.settings.sections.background.type.api
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "custom",
            children: quote.custom
          })]
        }), quoteSettings, /*#__PURE__*/(0,jsx_runtime.jsx)(Slider, {
          title: window.language.modals.main.settings.sections.appearance.accessibility.widget_zoom,
          name: "zoomQuote",
          min: "10",
          max: "400",
          default: "100",
          display: "%",
          category: "quote",
          element: ".quotediv"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: quote.buttons.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "copyButton",
          text: quote.buttons.copy,
          category: "quote"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "tweetButton",
          text: quote.buttons.tweet,
          category: "quote"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "favouriteQuoteEnabled",
          text: quote.buttons.favourite,
          category: "quote"
        })]
      });
    }
  }]);

  return QuoteSettings;
}(react.PureComponent);


;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/Appearance.jsx
var Appearance_br, Appearance_br2, Appearance_br3;









function AppearanceSettings() {
  var appearance = window.language.modals.main.settings.sections.appearance;
  var themeOptions = [{
    name: appearance.theme.auto,
    value: 'auto'
  }, {
    name: appearance.theme.light,
    value: 'light'
  }, {
    name: appearance.theme.dark,
    value: 'dark'
  }];
  return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h2", {
      children: appearance.title
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(Radio, {
      name: "theme",
      title: appearance.theme.title,
      options: themeOptions,
      category: "other"
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
      children: appearance.navbar.title
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
      name: "notesEnabled",
      text: appearance.navbar.notes,
      element: ".other"
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
      name: "refresh",
      text: appearance.navbar.refresh,
      element: ".other"
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
      children: appearance.font.title
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(Text, {
      title: appearance.font.custom,
      name: "font",
      upperCaseFirst: true,
      category: "other"
    }), Appearance_br || (Appearance_br = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
      name: "fontGoogle",
      text: appearance.font.google,
      category: "other"
    }), /*#__PURE__*/(0,jsx_runtime.jsxs)(Dropdown/* default */.Z, {
      label: appearance.font.weight.title,
      name: "fontweight",
      category: "other",
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)("option", {
        value: "100",
        children: appearance.font.weight.thin
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
        value: "200",
        children: appearance.font.weight.extra_light
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
        value: "300",
        children: appearance.font.weight.light
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
        value: "400",
        children: appearance.font.weight.normal
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
        value: "500",
        children: appearance.font.weight.medium
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
        value: "600",
        children: appearance.font.weight.semi_bold
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
        value: "700",
        children: appearance.font.weight.bold
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
        value: "800",
        children: appearance.font.weight.extra_bold
      })]
    }), Appearance_br2 || (Appearance_br2 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), Appearance_br3 || (Appearance_br3 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsxs)(Dropdown/* default */.Z, {
      label: appearance.font.style.title,
      name: "fontstyle",
      category: "other",
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)("option", {
        value: "normal",
        children: appearance.font.style.normal
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
        value: "italic",
        children: appearance.font.style.italic
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
        value: "oblique",
        children: appearance.font.style.oblique
      })]
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
      children: appearance.accessibility.title
    }), navigator.userAgent.includes('Chrome') && typeof InstallTrigger === 'undefined' ? /*#__PURE__*/(0,jsx_runtime.jsx)(Slider, {
      title: appearance.accessibility.widget_zoom,
      name: "widgetzoom",
      default: "100",
      step: "10",
      min: "50",
      max: "200",
      display: "%",
      category: "other"
    }) : null, /*#__PURE__*/(0,jsx_runtime.jsx)(Slider, {
      title: appearance.accessibility.toast_duration,
      name: "toastDisplayTime",
      default: "2500",
      step: "100",
      min: "500",
      max: "5000",
      toast: true,
      display: ' ' + appearance.accessibility.milliseconds
    })]
  });
}
// EXTERNAL MODULE: ./src/components/modals/main/settings/FileUpload.jsx
var FileUpload = __webpack_require__(9469);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__(484);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js + 2 modules
var toConsumableArray = __webpack_require__(5061);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/toArray.js
var toArray = __webpack_require__(9809);
// EXTERNAL MODULE: ./node_modules/react-color-gradient-picker/dist/index-cjs.js
var index_cjs = __webpack_require__(1766);
;// CONCATENATED MODULE: ./src/modules/helpers/background/rgbToHsv.js
function rgbToHSv(_ref) {
  var red = _ref.red,
      green = _ref.green,
      blue = _ref.blue;
  var rr, gg, bb, h, s;
  var rabs = red / 255;
  var gabs = green / 255;
  var babs = blue / 255;
  var v = Math.max(rabs, gabs, babs);
  var diff = v - Math.min(rabs, gabs, babs);

  var diffc = function diffc(c) {
    return (v - c) / 6 / diff + 1 / 2;
  };

  if (diff === 0) {
    h = 0;
    s = 0;
  } else {
    s = diff / v;
    rr = diffc(rabs);
    gg = diffc(gabs);
    bb = diffc(babs);

    if (rabs === v) {
      h = bb - gg;
    } else if (gabs === v) {
      h = 1 / 3 + rr - bb;
    } else if (babs === v) {
      h = 2 / 3 + gg - rr;
    }

    if (h < 0) {
      h += 1;
    } else if (h > 1) {
      h -= 1;
    }
  }

  return {
    hue: Math.round(h * 360),
    saturation: Math.round(s * 100),
    value: Math.round(v * 100)
  };
}
;// CONCATENATED MODULE: ./src/modules/helpers/background/setRgba.js
var isValidRGBValue = function isValidRGBValue(value) {
  return typeof value === 'number' && Number.isNaN(value) === false && value >= 0 && value <= 255;
};

function setRGBA(red, green, blue, alpha) {
  if (isValidRGBValue(red) && isValidRGBValue(green) && isValidRGBValue(blue)) {
    var color = {
      red: red | 0,
      green: green | 0,
      blue: blue | 0
    };

    if (isValidRGBValue(alpha) === true) {
      color.alpha = alpha | 0;
    }

    return color;
  }
}
;// CONCATENATED MODULE: ./src/modules/helpers/background/hexToRgb.js


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,defineProperty/* default */.Z)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }



var hexRegexp = /(^#{0,1}[0-9A-F]{6}$)|(^#{0,1}[0-9A-F]{3}$)|(^#{0,1}[0-9A-F]{8}$)/i;
var regexp = /([0-9A-F])([0-9A-F])([0-9A-F])/i;
function hexToRgb(value) {
  var valid = hexRegexp.test(value);

  if (valid) {
    if (value[0] === '#') {
      value = value.slice(1, value.length);
    }

    if (value.length === 3) {
      value = value.replace(regexp, '$1$1$2$2$3$3');
    }

    var red = parseInt(value.substr(0, 2), 16);
    var green = parseInt(value.substr(2, 2), 16);
    var blue = parseInt(value.substr(4, 2), 16);
    var alpha = parseInt(value.substr(6, 2), 16) / 255;
    var color = setRGBA(red, green, blue, alpha);
    var hsv = rgbToHSv(_objectSpread({}, color));
    return _objectSpread(_objectSpread({}, color), hsv);
  }

  return false;
}
;// CONCATENATED MODULE: ./src/modules/helpers/background/rgbToHex.js
function rgbToHex(red, green, blue) {
  var r16 = red.toString(16);
  var g16 = green.toString(16);
  var b16 = blue.toString(16);

  if (red < 16) {
    r16 = "0".concat(r16);
  }

  if (green < 16) {
    g16 = "0".concat(g16);
  }

  if (blue < 16) {
    b16 = "0".concat(b16);
  }

  return r16 + g16 + b16;
}
;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/background/Colour.jsx











var Colour_br, Colour_br2;

function Colour_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Colour_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Colour_ownKeys(Object(source), true).forEach(function (key) { (0,defineProperty/* default */.Z)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Colour_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Colour_createSuper(Derived) { var hasNativeReflectConstruct = Colour_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Colour_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }












var ColourSettings = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(ColourSettings, _React$PureComponent);

  var _super = Colour_createSuper(ColourSettings);

  function ColourSettings() {
    var _this;

    (0,classCallCheck/* default */.Z)(this, ColourSettings);

    _this = _super.call(this);

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "DefaultGradientSettings", {
      angle: '180',
      gradient: [{
        colour: '#ffb032',
        stop: 0
      }],
      type: 'linear'
    });

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "GradientPickerInitalState", undefined);

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "onGradientChange", function (event, index) {
      var newValue = event.target.value;
      var name = event.target.name;

      _this.setState(function (s) {
        var newState = {
          gradientSettings: Colour_objectSpread(Colour_objectSpread({}, s.gradientSettings), {}, {
            gradient: s.gradientSettings.gradient.map(function (g, i) {
              return i === index ? Colour_objectSpread(Colour_objectSpread({}, g), {}, (0,defineProperty/* default */.Z)({}, name, newValue)) : g;
            })
          })
        };
        return newState;
      });

      var reminderInfo = document.querySelector('.reminder-info');

      if (reminderInfo.style.display !== 'block') {
        reminderInfo.style.display = 'block';
        localStorage.setItem('showReminder', true);
      }
    });

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "addColour", function () {
      _this.setState(function (s) {
        var _s$gradientSettings$g = s.gradientSettings.gradient.reverse(),
            _s$gradientSettings$g2 = (0,toArray/* default */.Z)(_s$gradientSettings$g),
            lastGradient = _s$gradientSettings$g2[0],
            initGradients = _s$gradientSettings$g2.slice(1);

        var newState = {
          gradientSettings: Colour_objectSpread(Colour_objectSpread({}, s.gradientSettings), {}, {
            gradient: [].concat((0,toConsumableArray/* default */.Z)(initGradients), [lastGradient, {
              colour: localStorage.getItem('theme') === 'dark' ? '#000000' : '#ffffff',
              stop: 100
            }]).sort(function (a, b) {
              return a.stop > b.stop ? 1 : -1;
            })
          })
        };
        return newState;
      });

      window.analytics.postEvent('setting', 'Changed backgroundtype from colour to gradient');
    });

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "currentGradientSettings", function () {
      if ((0,esm_typeof/* default */.Z)(_this.state.gradientSettings) === 'object' && _this.state.gradientSettings.gradient.every(function (g) {
        return g.colour !== _this.language.sections.background.source.disabled;
      })) {
        var clampNumber = function clampNumber(num, a, b) {
          return Math.max(Math.min(num, Math.max(a, b)), Math.min(a, b));
        };

        return JSON.stringify(Colour_objectSpread(Colour_objectSpread({}, _this.state.gradientSettings), {}, {
          gradient: (0,toConsumableArray/* default */.Z)(_this.state.gradientSettings.gradient.map(function (g) {
            return Colour_objectSpread(Colour_objectSpread({}, g), {}, {
              stop: clampNumber(+g.stop, 0, 100)
            });
          })).sort(function (a, b) {
            return a.stop > b.stop ? 1 : -1;
          })
        }));
      }

      return _this.language.sections.background.source.disabled;
    });

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "onColourPickerChange", function (attrs, name) {
      if (false) {}

      _this.setState({
        gradientSettings: {
          angle: attrs.degree,
          gradient: attrs.points.map(function (p) {
            return {
              colour: '#' + rgbToHex(p.red, p.green, p.blue),
              stop: p.left
            };
          }),
          type: attrs.type
        }
      });

      var reminderInfo = document.querySelector('.reminder-info');

      if (reminderInfo.style.display !== 'block') {
        reminderInfo.style.display = 'block';
        localStorage.setItem('showReminder', true);
      }
    });

    _this.state = {
      gradientSettings: _this.DefaultGradientSettings
    };
    _this.language = window.language.modals.main.settings;
    return _this;
  }

  (0,createClass/* default */.Z)(ColourSettings, [{
    key: "resetColour",
    value: function resetColour() {
      localStorage.setItem('customBackgroundColour', '');
      this.setState({
        gradientSettings: this.DefaultGradientSettings
      });
      (0,react_toastify_esm/* toast */.Am)(window.language.toasts.reset);
    }
  }, {
    key: "initialiseColourPickerState",
    value: function initialiseColourPickerState(gradientSettings) {
      this.GradientPickerInitalState = {
        points: gradientSettings.gradient.map(function (g) {
          var rgb = hexToRgb(g.colour);
          return {
            left: +g.stop,
            red: rgb.red,
            green: rgb.green,
            blue: rgb.blue,
            alpha: 1
          };
        }),
        degree: +gradientSettings.angle,
        type: gradientSettings.type
      };
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var hex = localStorage.getItem('customBackgroundColour');
      var gradientSettings = undefined;

      if (hex !== '') {
        try {
          gradientSettings = JSON.parse(hex);
        } catch (e) {// Disregard exception.
        }
      }

      if (gradientSettings === undefined) {
        gradientSettings = this.DefaultGradientSettings;
      }

      this.setState({
        gradientSettings: gradientSettings
      });
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      localStorage.setItem('customBackgroundColour', document.getElementById('customBackgroundHex').value);
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var background = this.language.sections.background;
      var colourSettings = null;

      if ((0,esm_typeof/* default */.Z)(this.state.gradientSettings) === 'object') {
        var gradientHasMoreThanOneColour = this.state.gradientSettings.gradient.length > 1;
        var gradientInputs;

        if (gradientHasMoreThanOneColour) {
          if (this.GradientPickerInitalState === undefined) {
            this.initialiseColourPickerState(this.state.gradientSettings);
          }

          gradientInputs = /*#__PURE__*/(0,jsx_runtime.jsx)(index_cjs/* ColorPicker */.z, {
            onStartChange: function onStartChange(colour) {
              return _this2.onColourPickerChange(colour, 'start');
            },
            onChange: function onChange(colour) {
              return _this2.onColourPickerChange(colour, 'change');
            },
            onEndChange: function onEndChange(colour) {
              return _this2.onColourPickerChange(colour, 'end');
            },
            gradient: this.GradientPickerInitalState,
            isGradient: true
          });
        } else {
          gradientInputs = this.state.gradientSettings.gradient.map(function (g, i) {
            return /*#__PURE__*/(0,jsx_runtime.jsxs)(react.Fragment, {
              children: [/*#__PURE__*/(0,jsx_runtime.jsx)("input", {
                id: 'colour_' + i,
                type: "color",
                name: "colour",
                className: "colour",
                onChange: function onChange(event) {
                  return _this2.onGradientChange(event, i);
                },
                value: g.colour
              }), /*#__PURE__*/(0,jsx_runtime.jsx)("label", {
                htmlFor: 'colour_' + i,
                className: "customBackgroundHex",
                children: g.colour
              })]
            }, i);
          });
        }

        colourSettings = /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
          children: [gradientInputs, !gradientHasMoreThanOneColour ? /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
            children: [Colour_br || (Colour_br = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), Colour_br2 || (Colour_br2 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsx)("button", {
              type: "button",
              className: "add",
              onClick: this.addColour,
              children: background.source.add_colour
            })]
          }) : null]
        });
      }

      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
          children: [background.source.custom_colour, " ", /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
            className: "modalLink",
            onClick: function onClick() {
              return _this2.resetColour();
            },
            children: this.language.buttons.reset
          })]
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("input", {
          id: "customBackgroundHex",
          type: "hidden",
          value: this.currentGradientSettings()
        }), colourSettings]
      });
    }
  }]);

  return ColourSettings;
}(react.PureComponent);


;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/background/Background.jsx









var Background_br, Background_br2, Background_br3, Background_br4, _ColourSettings, Background_br5, _br6, _br7;



function Background_createSuper(Derived) { var hasNativeReflectConstruct = Background_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Background_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }















var Background_BackgroundSettings = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(BackgroundSettings, _React$PureComponent);

  var _super = Background_createSuper(BackgroundSettings);

  function BackgroundSettings() {
    var _this;

    (0,classCallCheck/* default */.Z)(this, BackgroundSettings);

    _this = _super.call(this);

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "resetCustom", function () {
      localStorage.setItem('customBackground', '');

      _this.setState({
        customBackground: ''
      });

      (0,react_toastify_esm/* toast */.Am)(window.language.toasts.reset);
      eventbus/* default.dispatch */.Z.dispatch('refresh', 'background');
    });

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "videoCustomSettings", function () {
      var customBackground = _this.state.customBackground;

      if (customBackground.startsWith('data:video/') || customBackground.endsWith('.mp4') || customBackground.endsWith('.webm') || customBackground.endsWith('.ogg')) {
        return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
          children: [/*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
            name: "backgroundVideoLoop",
            text: _this.language.sections.background.source.loop_video
          }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
            name: "backgroundVideoMute",
            text: _this.language.sections.background.source.mute_video
          })]
        });
      } else {
        return null;
      }
    });

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "marketplaceType", function () {
      if (localStorage.getItem('photo_packs')) {
        return /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
          value: "photo_pack",
          children: window.language.modals.main.navbar.marketplace
        });
      }
    });

    _this.state = {
      customBackground: localStorage.getItem('customBackground') || '',
      backgroundType: localStorage.getItem('backgroundType') || 'api',
      backgroundCategories: [window.language.modals.main.loading]
    };
    _this.language = window.language.modals.main.settings;
    _this.controller = new AbortController();
    return _this;
  }

  (0,createClass/* default */.Z)(BackgroundSettings, [{
    key: "customBackground",
    value: function customBackground(e, text) {
      var result = text === true ? e.target.value : e.target.result;
      localStorage.setItem('customBackground', result);
      this.setState({
        customBackground: result
      });
      eventbus/* default.dispatch */.Z.dispatch('refresh', 'background');
    }
  }, {
    key: "getBackgroundCategories",
    value: function () {
      var _getBackgroundCategories = (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee() {
        var data;
        return regenerator_default().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return fetch(window.constants.API_URL + '/images/categories', {
                  signal: this.controller.signal
                });

              case 2:
                _context.next = 4;
                return _context.sent.json();

              case 4:
                data = _context.sent;

                if (!(this.controller.signal.aborted === true)) {
                  _context.next = 7;
                  break;
                }

                return _context.abrupt("return");

              case 7:
                this.setState({
                  backgroundCategories: data
                });

              case 8:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function getBackgroundCategories() {
        return _getBackgroundCategories.apply(this, arguments);
      }

      return getBackgroundCategories;
    }()
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      if (navigator.onLine === false || localStorage.getItem('offlineMode') === 'true') {
        return this.setState({
          backgroundCategories: [window.language.modals.update.offline.title]
        });
      }

      this.getBackgroundCategories();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      // stop making requests
      this.controller.abort();
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var background = this.language.sections.background;
      var backgroundSettings;
      var apiOptions = [{
        name: 'Mue',
        value: 'mue'
      }, {
        name: 'Unsplash',
        value: 'unsplash'
      }, {
        name: 'Pexels',
        value: 'pexels'
      }];

      var APISettings = /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [Background_br || (Background_br = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsx)(Radio, {
          title: background.source.api,
          options: apiOptions,
          name: "backgroundAPI",
          category: "background"
        }), Background_br2 || (Background_br2 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsx)(Dropdown/* default */.Z, {
          label: background.category,
          name: "apiCategory",
          children: this.state.backgroundCategories.map(function (category) {
            return /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
              value: category,
              children: category.charAt(0).toUpperCase() + category.slice(1)
            }, category);
          })
        }), Background_br3 || (Background_br3 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), Background_br4 || (Background_br4 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsxs)(Dropdown/* default */.Z, {
          label: background.source.quality.title,
          name: "apiQuality",
          category: "background",
          element: ".other",
          children: [/*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "original",
            children: background.source.quality.original
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "high",
            children: background.source.quality.high
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "normal",
            children: background.source.quality.normal
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "datasaver",
            children: background.source.quality.datasaver
          })]
        })]
      });

      var customSettings = /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("ul", {
          children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
            children: [background.source.custom_background, " ", /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
              className: "modalLink",
              onClick: this.resetCustom,
              children: this.language.buttons.reset
            })]
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("input", {
            type: "text",
            value: this.state.customBackground,
            onChange: function onChange(e) {
              return _this2.customBackground(e, true);
            }
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
            className: "modalLink",
            onClick: function onClick() {
              return document.getElementById('bg-input').click();
            },
            children: background.source.upload
          }), /*#__PURE__*/(0,jsx_runtime.jsx)(FileUpload/* default */.Z, {
            id: "bg-input",
            accept: "image/jpeg, image/png, image/webp, image/webm, image/gif, video/mp4, video/webm, video/ogg",
            loadFunction: function loadFunction(e) {
              return _this2.customBackground(e);
            }
          })]
        }), this.videoCustomSettings()]
      });

      switch (this.state.backgroundType) {
        case 'custom':
          backgroundSettings = customSettings;
          break;

        case 'colour':
          backgroundSettings = _ColourSettings || (_ColourSettings = /*#__PURE__*/(0,jsx_runtime.jsx)(ColourSettings, {}));
          break;

        default:
          backgroundSettings = APISettings;
          break;
      }

      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h2", {
          children: background.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Switch, {
          name: "background",
          text: this.language.enabled,
          category: "background"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "ddgProxy",
          text: background.ddg_proxy
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "bgtransition",
          text: background.transition
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "photoInformation",
          text: background.photo_information,
          category: "background",
          element: ".other"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: background.source.title
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)(Dropdown/* default */.Z, {
          label: background.type.title,
          name: "backgroundType",
          onChange: function onChange(value) {
            return _this2.setState({
              backgroundType: value
            });
          },
          category: "background",
          children: [this.marketplaceType(), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "api",
            children: background.type.api
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "custom",
            children: background.type.custom_image
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "colour",
            children: background.type.custom_colour
          })]
        }), Background_br5 || (Background_br5 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), backgroundSettings, /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: background.buttons.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "view",
          text: background.buttons.view,
          element: ".other"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "favouriteEnabled",
          text: background.buttons.favourite,
          element: ".other"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "downloadbtn",
          text: background.buttons.download,
          element: ".other"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: background.effects.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Slider, {
          title: background.effects.blur,
          name: "blur",
          min: "0",
          max: "100",
          default: "0",
          display: "%",
          category: "background"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Slider, {
          title: background.effects.brightness,
          name: "brightness",
          min: "0",
          max: "100",
          default: "90",
          display: "%",
          category: "background"
        }), _br6 || (_br6 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), _br7 || (_br7 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsxs)(Dropdown/* default */.Z, {
          label: background.effects.filters.title,
          name: "backgroundFilter",
          category: "background",
          children: [/*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "grayscale",
            children: background.effects.filters.grayscale
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "sepia",
            children: background.effects.filters.sepia
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "invert",
            children: background.effects.filters.invert
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "saturate",
            children: background.effects.filters.saturate
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "contrast",
            children: background.effects.filters.contrast
          })]
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Slider, {
          title: background.effects.filters.amount,
          name: "backgroundFilterAmount",
          min: "0",
          max: "100",
          default: "0",
          display: "%",
          category: "background"
        })]
      });
    }
  }]);

  return BackgroundSettings;
}(react.PureComponent);


;// CONCATENATED MODULE: ./src/components/modals/main/settings/ResetModal.jsx




function ResetModal(props) {
  var language = window.language.modals.main.settings.sections.advanced.reset_modal;

  var reset = function reset() {
    window.analytics.postEvent('setting', 'Reset');
    settings/* default.setDefaultSettings */.Z.setDefaultSettings('reset');
    window.location.reload();
  };

  return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
      style: {
        'textAlign': 'center'
      },
      children: language.title
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("h4", {
      children: language.question
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("p", {
      children: language.information
    }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "resetfooter",
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)("button", {
        className: "reset",
        style: {
          'marginLeft': '0'
        },
        onClick: function onClick() {
          return reset();
        },
        children: window.language.modals.main.settings.buttons.reset
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("button", {
        className: "import",
        style: {
          'marginLeft': '5px'
        },
        onClick: props.modalClose,
        children: language.cancel
      })]
    })]
  });
}
// EXTERNAL MODULE: ./node_modules/react-modal/lib/index.js
var lib = __webpack_require__(3253);
var lib_default = /*#__PURE__*/__webpack_require__.n(lib);
;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/Advanced.jsx






function Advanced_createSuper(Derived) { var hasNativeReflectConstruct = Advanced_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Advanced_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }














var AdvancedSettings = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(AdvancedSettings, _React$PureComponent);

  var _super = Advanced_createSuper(AdvancedSettings);

  function AdvancedSettings() {
    var _this;

    (0,classCallCheck/* default */.Z)(this, AdvancedSettings);

    _this = _super.call(this);
    _this.state = {
      resetModal: false
    };
    _this.language = window.language.modals.main.settings;
    return _this;
  }

  (0,createClass/* default */.Z)(AdvancedSettings, [{
    key: "settingsImport",
    value: function settingsImport(e) {
      var content = JSON.parse(e.target.result);
      Object.keys(content).forEach(function (key) {
        localStorage.setItem(key, content[key]);
      });
      (0,react_toastify_esm/* toast */.Am)(window.language.toasts.imported);
      window.analytics.postEvent('tab', 'Settings imported');
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var advanced = this.language.sections.advanced;
      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h2", {
          children: advanced.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "offlineMode",
          text: advanced.offline_mode,
          element: ".other"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: advanced.data
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("button", {
          className: "reset",
          onClick: function onClick() {
            return _this2.setState({
              resetModal: true
            });
          },
          children: this.language.buttons.reset
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("button", {
          className: "export",
          onClick: function onClick() {
            return settings/* default.exportSettings */.Z.exportSettings();
          },
          children: this.language.buttons.export
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("button", {
          className: "import",
          onClick: function onClick() {
            return document.getElementById('file-input').click();
          },
          children: this.language.buttons.import
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(FileUpload/* default */.Z, {
          id: "file-input",
          accept: "application/json",
          type: "settings",
          loadFunction: function loadFunction(e) {
            return _this2.settingsImport(e);
          }
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: advanced.customisation
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Text, {
          title: advanced.tab_name,
          name: "tabName",
          default: window.language.tabname,
          category: "other"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Text, {
          title: advanced.custom_js,
          name: "customjs",
          textarea: true,
          category: "other",
          element: "other"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Text, {
          title: advanced.custom_css,
          name: "customcss",
          textarea: true,
          category: "other"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: this.language.sections.experimental.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("p", {
          style: {
            'maxWidth': '75%'
          },
          children: advanced.experimental_warning
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Switch, {
          name: "experimental",
          text: this.language.enabled,
          element: ".other"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)((lib_default()), {
          closeTimeoutMS: 100,
          onRequestClose: function onRequestClose() {
            return _this2.setState({
              resetModal: false
            });
          },
          isOpen: this.state.resetModal,
          className: "Modal resetmodal mainModal",
          overlayClassName: "Overlay resetoverlay",
          ariaHideApp: false,
          children: /*#__PURE__*/(0,jsx_runtime.jsx)(ResetModal, {
            modalClose: function modalClose() {
              return _this2.setState({
                resetModal: false
              });
            }
          })
        })]
      });
    }
  }]);

  return AdvancedSettings;
}(react.PureComponent);


// EXTERNAL MODULE: ./src/components/modals/main/marketplace/Lightbox.jsx
var Lightbox = __webpack_require__(155);
// EXTERNAL MODULE: ./node_modules/@material-ui/icons/WifiOff.js
var WifiOff = __webpack_require__(7091);
;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/Changelog.jsx







var _WifiOffIcon;



function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function Changelog_createSuper(Derived) { var hasNativeReflectConstruct = Changelog_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Changelog_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }









var Changelog = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(Changelog, _React$PureComponent);

  var _super = Changelog_createSuper(Changelog);

  function Changelog() {
    var _this;

    (0,classCallCheck/* default */.Z)(this, Changelog);

    _this = _super.call(this);
    _this.state = {
      title: null,
      showLightbox: false,
      lightboxImg: null
    };
    _this.language = window.language.modals.update;
    _this.controller = new AbortController();
    return _this;
  }

  (0,createClass/* default */.Z)(Changelog, [{
    key: "getUpdate",
    value: function () {
      var _getUpdate = (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee() {
        var _this2 = this;

        var data, date, content, images, links, _iterator, _step, _loop, link;

        return regenerator_default().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return fetch(window.constants.BLOG_POST + '/index.json', {
                  signal: this.controller.signal
                });

              case 2:
                _context.next = 4;
                return _context.sent.json();

              case 4:
                data = _context.sent;

                if (!(this.controller.signal.aborted === true)) {
                  _context.next = 7;
                  break;
                }

                return _context.abrupt("return");

              case 7:
                date = new Date(data.date);
                date = date.toLocaleDateString(window.languagecode.replace('_', '-'), {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                });
                this.setState({
                  title: data.title,
                  date: date,
                  image: data.featured_image || null,
                  author: 'By ' + data.authors.join(', '),
                  html: data.html
                }); // lightbox etc

                content = document.querySelector('.tab-content');
                images = content.getElementsByTagName('img');
                links = content.getElementsByTagName('a');
                _iterator = _createForOfIteratorHelper(images);

                try {
                  _loop = function _loop() {
                    var img = _step.value;
                    img.draggable = false;

                    img.onclick = function () {
                      _this2.setState({
                        showLightbox: true,
                        lightboxImg: img.src
                      });
                    };
                  };

                  for (_iterator.s(); !(_step = _iterator.n()).done;) {
                    _loop();
                  }
                } catch (err) {
                  _iterator.e(err);
                } finally {
                  _iterator.f();
                }

                for (link = 0; link < links.length; link++) {
                  links[link].target = '_blank';
                  links[link].rel = 'noopener noreferrer';
                }

              case 16:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      function getUpdate() {
        return _getUpdate.apply(this, arguments);
      }

      return getUpdate;
    }()
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      if (navigator.onLine === false || localStorage.getItem('offlineMode') === 'true') {
        return;
      }

      this.getUpdate();
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      // stop making requests
      this.controller.abort();
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var errorMessage = function errorMessage(msg) {
        return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
          className: "emptyitems",
          children: /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
            className: "emptyMessage",
            children: msg
          })
        });
      };

      if (navigator.onLine === false || localStorage.getItem('offlineMode') === 'true') {
        var language = window.language.modals.main.marketplace;
        return errorMessage( /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
          children: [_WifiOffIcon || (_WifiOffIcon = /*#__PURE__*/(0,jsx_runtime.jsx)(WifiOff/* default */.Z, {})), /*#__PURE__*/(0,jsx_runtime.jsx)("h1", {
            children: language.offline.title
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("p", {
            className: "description",
            children: language.offline.description
          })]
        }));
      }

      if (!this.state.title) {
        return errorMessage( /*#__PURE__*/(0,jsx_runtime.jsx)("h1", {
          children: window.language.modals.main.loading
        }));
      }

      return /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
        className: "changelogtab",
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h1", {
          style: {
            'marginBottom': '-10px'
          },
          children: this.state.title
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("h5", {
          style: {
            'lineHeight': '0px'
          },
          children: [this.state.author, " \u2022 ", this.state.date]
        }), this.state.image ? /*#__PURE__*/(0,jsx_runtime.jsx)("img", {
          draggable: "false",
          src: this.state.image,
          alt: window.language.modals.update.title,
          className: "updateimage"
        }) : null, /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
          className: "updatechangelog",
          dangerouslySetInnerHTML: {
            __html: this.state.html
          }
        }), /*#__PURE__*/(0,jsx_runtime.jsx)((lib_default()), {
          closeTimeoutMS: 100,
          onRequestClose: function onRequestClose() {
            return _this3.setState({
              showLightbox: false
            });
          },
          isOpen: this.state.showLightbox,
          className: "Modal lightboxmodal",
          overlayClassName: "Overlay resetoverlay",
          ariaHideApp: false,
          children: /*#__PURE__*/(0,jsx_runtime.jsx)(Lightbox/* default */.Z, {
            modalClose: function modalClose() {
              return _this3.setState({
                showLightbox: false
              });
            },
            img: this.state.lightboxImg
          })
        })]
      });
    }
  }]);

  return Changelog;
}(react.PureComponent);


// EXTERNAL MODULE: ./node_modules/@material-ui/icons/DragIndicator.js
var DragIndicator = __webpack_require__(5989);
// EXTERNAL MODULE: ./node_modules/react-sortable-hoc/dist/react-sortable-hoc.esm.js + 1 modules
var react_sortable_hoc_esm = __webpack_require__(4140);
;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/Order.jsx









function Order_createSuper(Derived) { var hasNativeReflectConstruct = Order_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Order_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }










var enabled = function enabled(setting) {
  switch (setting) {
    case 'quicklinks':
      return localStorage.getItem('quicklinksenabled') === 'true';

    default:
      return localStorage.getItem(setting) === 'true';
  }
};

var Order_settings = window.language.modals.main.settings.sections;
var widget_name = {
  greeting: Order_settings.greeting.title,
  time: Order_settings.time.title,
  quicklinks: Order_settings.quicklinks.title,
  quote: Order_settings.quote.title,
  date: Order_settings.time.date.title
};
var SortableItem = (0,react_sortable_hoc_esm/* sortableElement */.gU)(function (_ref) {
  var value = _ref.value;
  return /*#__PURE__*/(0,jsx_runtime.jsxs)("li", {
    className: "sortableitem",
    style: {
      display: enabled(value) ? 'block' : 'none'
    },
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)(DragIndicator/* default */.Z, {
      style: {
        'verticalAlign': 'middle'
      }
    }), widget_name[value]]
  });
});
var SortableContainer = (0,react_sortable_hoc_esm/* sortableContainer */.hv)(function (_ref2) {
  var children = _ref2.children;
  return /*#__PURE__*/(0,jsx_runtime.jsx)("ul", {
    className: "sortablecontainer",
    children: children
  });
});

var OrderSettings = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(OrderSettings, _React$PureComponent);

  var _super = Order_createSuper(OrderSettings);

  function OrderSettings() {
    var _this;

    (0,classCallCheck/* default */.Z)(this, OrderSettings);

    _this = _super.call(this);

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "onSortEnd", function (_ref3) {
      var oldIndex = _ref3.oldIndex,
          newIndex = _ref3.newIndex;

      _this.setState({
        items: _this.arrayMove(_this.state.items, oldIndex, newIndex)
      });
    });

    (0,defineProperty/* default */.Z)((0,assertThisInitialized/* default */.Z)(_this), "reset", function () {
      localStorage.setItem('order', JSON.stringify(['greeting', 'time', 'quicklinks', 'quote', 'date']));

      _this.setState({
        items: JSON.parse(localStorage.getItem('order'))
      });

      (0,react_toastify_esm/* toast */.Am)(window.language.toasts.reset);
    });

    _this.state = {
      items: JSON.parse(localStorage.getItem('order'))
    };
    _this.language = window.language.modals.main.settings;
    return _this;
  } // based on https://stackoverflow.com/a/48301905


  (0,createClass/* default */.Z)(OrderSettings, [{
    key: "arrayMove",
    value: function arrayMove(array, oldIndex, newIndex) {
      if (oldIndex === newIndex) {
        return array;
      }

      var newArray = (0,toConsumableArray/* default */.Z)(array);

      var target = newArray[oldIndex];
      var inc = newIndex < oldIndex ? -1 : 1;

      for (var i = oldIndex; i !== newIndex; i += inc) {
        newArray[i] = newArray[i + inc];
      }

      newArray[newIndex] = target;
      return newArray;
    }
  }, {
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      localStorage.setItem('order', JSON.stringify(this.state.items));
      window.analytics.postEvent('setting', 'Widget order');
      eventbus/* default.dispatch */.Z.dispatch('refresh', 'widgets');
    }
  }, {
    key: "render",
    value: function render() {
      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h2", {
          children: this.language.sections.order.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
          className: "modalLink",
          onClick: this.reset,
          children: this.language.buttons.reset
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(SortableContainer, {
          onSortEnd: this.onSortEnd,
          lockAxis: "y",
          lockToContainerEdges: true,
          disableAutoscroll: true,
          children: this.state.items.map(function (value, index) {
            return /*#__PURE__*/(0,jsx_runtime.jsx)(SortableItem, {
              index: index,
              value: value
            }, "item-".concat(value));
          })
        })]
      });
    }
  }]);

  return OrderSettings;
}(react.PureComponent);


;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/Experimental.jsx
var _Checkbox, _Slider, Experimental_br, Experimental_p, _input, Experimental_br2, Experimental_br3, _input2, Experimental_br4, Experimental_br5, Experimental_br6, Experimental_br7;







function ExperimentalSettings() {
  var experimental = window.language.modals.main.settings.sections.experimental;
  return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h2", {
      children: experimental.title
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("p", {
      children: experimental.warning
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
      name: "animations",
      text: window.language.modals.main.settings.sections.appearance.animations,
      element: ".other"
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
      children: experimental.developer
    }), _Checkbox || (_Checkbox = /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
      name: "debug",
      text: "Debug hotkey (Ctrl + #)",
      element: ".other"
    })), _Slider || (_Slider = /*#__PURE__*/(0,jsx_runtime.jsx)(Slider, {
      title: "Debug timeout",
      name: "debugtimeout",
      min: "0",
      max: "5000",
      default: "0",
      step: "100",
      display: " miliseconds",
      element: ".other"
    })), Experimental_br || (Experimental_br = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), Experimental_p || (Experimental_p = /*#__PURE__*/(0,jsx_runtime.jsx)("p", {
      children: "Send Event"
    })), "Type ", _input || (_input = /*#__PURE__*/(0,jsx_runtime.jsx)("input", {
      type: "text",
      id: "eventType"
    })), Experimental_br2 || (Experimental_br2 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), Experimental_br3 || (Experimental_br3 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), "Name ", _input2 || (_input2 = /*#__PURE__*/(0,jsx_runtime.jsx)("input", {
      type: "text",
      id: "eventName"
    })), Experimental_br4 || (Experimental_br4 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), Experimental_br5 || (Experimental_br5 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsx)("button", {
      className: "uploadbg",
      onClick: function onClick() {
        return eventbus/* default.dispatch */.Z.dispatch(document.getElementById('eventType').value, document.getElementById('eventName').value);
      },
      children: "Send"
    }), Experimental_br6 || (Experimental_br6 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), Experimental_br7 || (Experimental_br7 = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsx)("button", {
      className: "reset",
      style: {
        'marginLeft': '0px'
      },
      onClick: function onClick() {
        return localStorage.clear();
      },
      children: "Clear LocalStorage"
    })]
  });
}
;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/QuickLinks.jsx





function QuickLinks() {
  var language = window.language.modals.main.settings.sections.quicklinks;
  return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h2", {
      children: language.title
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(Switch, {
      name: "quicklinksenabled",
      text: window.language.modals.main.settings.enabled,
      category: "quicklinks",
      element: ".quicklinks-container"
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
      name: "quicklinksddgProxy",
      text: window.language.modals.main.settings.sections.background.ddg_proxy,
      element: ".other"
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
      name: "quicklinksnewtab",
      text: language.open_new,
      category: "quicklinks"
    }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
      name: "quicklinkstooltip",
      text: language.tooltip,
      category: "quicklinks"
    })]
  });
}
;// CONCATENATED MODULE: ./src/components/modals/main/settings/sections/Weather.jsx







var Weather_br;



function Weather_createSuper(Derived) { var hasNativeReflectConstruct = Weather_isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function Weather_isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }










var Weather_TimeSettings = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(TimeSettings, _React$PureComponent);

  var _super = Weather_createSuper(TimeSettings);

  function TimeSettings() {
    var _this;

    (0,classCallCheck/* default */.Z)(this, TimeSettings);

    _this = _super.call(this);
    _this.state = {
      location: localStorage.getItem('location') || 'London'
    };
    _this.language = window.language.modals.main.settings;
    return _this;
  }

  (0,createClass/* default */.Z)(TimeSettings, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate() {
      localStorage.setItem('location', this.state.location);
    }
  }, {
    key: "changeLocation",
    value: function changeLocation(e) {
      this.setState({
        location: e.target.value
      });
      document.querySelector('.reminder-info').style.display = 'block';
      localStorage.setItem('showReminder', true);
    }
  }, {
    key: "getAuto",
    value: function getAuto() {
      var _this2 = this;

      navigator.geolocation.getCurrentPosition( /*#__PURE__*/function () {
        var _ref = (0,asyncToGenerator/* default */.Z)( /*#__PURE__*/regenerator_default().mark(function _callee(position) {
          var data;
          return regenerator_default().wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  _context.next = 2;
                  return fetch("".concat(window.constants.WEATHER_URL, "/location?getAuto=true&lat=").concat(position.coords.latitude, "&lon=").concat(position.coords.longitude));

                case 2:
                  _context.next = 4;
                  return _context.sent.json();

                case 4:
                  data = _context.sent;

                  _this2.setState({
                    location: data[0].name
                  });

                  document.querySelector('.reminder-info').style.display = 'block';
                  localStorage.setItem('showReminder', true);

                case 8:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee);
        }));

        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }(), function (error) {
        // firefox requires this 2nd function
        console.log(error);
      }, {
        enableHighAccuracy: true
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var language = window.language.modals.main.settings.sections.weather;
      var tempFormat = [{
        name: language.temp_format.celsius + ' (°C)',
        value: 'celsius'
      }, {
        name: language.temp_format.fahrenheit + ' (°F)',
        value: 'fahrenheit'
      }, {
        name: language.temp_format.kelvin + ' (K)',
        value: 'kelvin'
      }];
      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h2", {
          children: language.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Switch, {
          name: "weatherEnabled",
          text: this.language.enabled,
          category: "widgets"
        }), /*#__PURE__*/(0,jsx_runtime.jsxs)("ul", {
          children: [/*#__PURE__*/(0,jsx_runtime.jsxs)("p", {
            children: [language.location, " ", /*#__PURE__*/(0,jsx_runtime.jsx)("span", {
              className: "modalLink",
              onClick: function onClick() {
                return _this3.getAuto();
              },
              children: language.auto
            })]
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("input", {
            type: "text",
            value: this.state.location,
            onChange: function onChange(e) {
              return _this3.changeLocation(e);
            }
          })]
        }), Weather_br || (Weather_br = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsx)(Radio, {
          name: "tempformat",
          title: language.temp_format.title,
          options: tempFormat,
          category: "weather"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Slider, {
          title: window.language.modals.main.settings.sections.appearance.accessibility.widget_zoom,
          name: "zoomWeather",
          min: "10",
          max: "400",
          default: "100",
          display: "%",
          category: "weather"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)("h3", {
          children: language.extra_info.title
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "showlocation",
          text: language.extra_info.show_location,
          category: "weather"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "weatherdescription",
          text: language.extra_info.show_description,
          category: "weather"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "cloudiness",
          text: language.extra_info.cloudiness,
          category: "weather"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "humidity",
          text: language.extra_info.humidity,
          category: "weather"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "visibility",
          text: language.extra_info.visibility,
          category: "weather"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "windspeed",
          text: language.extra_info.wind_speed,
          category: "weather"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "windDirection",
          text: language.extra_info.wind_direction,
          category: "weather"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "mintemp",
          text: language.extra_info.min_temp,
          category: "weather"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "maxtemp",
          text: language.extra_info.max_temp,
          category: "weather"
        }), /*#__PURE__*/(0,jsx_runtime.jsx)(Checkbox, {
          name: "atmosphericpressure",
          text: language.extra_info.atmospheric_pressure,
          category: "weather"
        })]
      });
    }
  }]);

  return TimeSettings;
}(react.PureComponent);


// EXTERNAL MODULE: ./src/components/modals/main/tabs/backend/Tabs.jsx + 2 modules
var Tabs = __webpack_require__(9027);
;// CONCATENATED MODULE: ./src/components/modals/main/tabs/Settings.jsx
var _Time, _Quote, _Greeting, _Background, _Search, _QuickLinks, _Weather, _Appearance, _Order, _Language, _Advanced, _Experimental, _Changelog, _About;



















function Settings() {
  var _window$language$moda = window.language.modals.main.settings,
      reminder = _window$language$moda.reminder,
      sections = _window$language$moda.sections;
  var display = 'none';

  if (localStorage.getItem('showReminder') === 'true') {
    display = 'block';
  }

  return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime.jsxs)(Tabs/* default */.Z, {
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        label: sections.time.title,
        children: _Time || (_Time = /*#__PURE__*/(0,jsx_runtime.jsx)(TimeSettings, {}))
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        label: sections.quote.title,
        children: _Quote || (_Quote = /*#__PURE__*/(0,jsx_runtime.jsx)(QuoteSettings, {}))
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        label: sections.greeting.title,
        children: _Greeting || (_Greeting = /*#__PURE__*/(0,jsx_runtime.jsx)(GreetingSettings, {}))
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        label: sections.background.title,
        children: _Background || (_Background = /*#__PURE__*/(0,jsx_runtime.jsx)(Background_BackgroundSettings, {}))
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        label: sections.search.title,
        children: _Search || (_Search = /*#__PURE__*/(0,jsx_runtime.jsx)(SearchSettings, {}))
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        label: sections.quicklinks.title,
        children: _QuickLinks || (_QuickLinks = /*#__PURE__*/(0,jsx_runtime.jsx)(QuickLinks, {}))
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        label: sections.weather.title,
        children: _Weather || (_Weather = /*#__PURE__*/(0,jsx_runtime.jsx)(Weather_TimeSettings, {}))
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        label: sections.appearance.title,
        children: _Appearance || (_Appearance = /*#__PURE__*/(0,jsx_runtime.jsx)(AppearanceSettings, {}))
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        label: sections.order.title,
        children: _Order || (_Order = /*#__PURE__*/(0,jsx_runtime.jsx)(OrderSettings, {}))
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        label: sections.language.title,
        children: _Language || (_Language = /*#__PURE__*/(0,jsx_runtime.jsx)(BackgroundSettings, {}))
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        label: sections.advanced.title,
        children: _Advanced || (_Advanced = /*#__PURE__*/(0,jsx_runtime.jsx)(AdvancedSettings, {}))
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        label: sections.experimental.title,
        children: _Experimental || (_Experimental = /*#__PURE__*/(0,jsx_runtime.jsx)(ExperimentalSettings, {}))
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        label: sections.changelog,
        children: _Changelog || (_Changelog = /*#__PURE__*/(0,jsx_runtime.jsx)(Changelog, {}))
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
        label: sections.about.title,
        children: _About || (_About = /*#__PURE__*/(0,jsx_runtime.jsx)(About, {}))
      })]
    }), /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "reminder-info",
      style: {
        'display': display
      },
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)("h1", {
        children: reminder.title
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("p", {
        children: reminder.message
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("button", {
        className: "pinNote",
        onClick: function onClick() {
          return window.location.reload();
        },
        children: window.language.modals.main.error_boundary.refresh
      })]
    })]
  });
}

/***/ }),

/***/ 1668:
/***/ (function(module) {

"use strict";
module.exports = JSON.parse('[{"login":"FuryingFox","avatar_url":"https://avatars.githubusercontent.com/u/28787893?v=4"}]');

/***/ })

}]);