(self["webpackChunkmue"] = self["webpackChunkmue"] || []).push([[843],{

/***/ 9826:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";
var __webpack_unused_export__;


var _interopRequireDefault = __webpack_require__(5318);

var _interopRequireWildcard = __webpack_require__(862);

__webpack_unused_export__ = ({
  value: true
});
exports.Z = void 0;

var React = _interopRequireWildcard(__webpack_require__(7294));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(2108));

var _default = (0, _createSvgIcon.default)( /*#__PURE__*/React.createElement("path", {
  d: "M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"
}), 'ArrowBack');

exports.Z = _default;

/***/ }),

/***/ 7826:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";
var __webpack_unused_export__;


var _interopRequireDefault = __webpack_require__(5318);

var _interopRequireWildcard = __webpack_require__(862);

__webpack_unused_export__ = ({
  value: true
});
exports.Z = void 0;

var React = _interopRequireWildcard(__webpack_require__(7294));

var _createSvgIcon = _interopRequireDefault(__webpack_require__(2108));

var _default = (0, _createSvgIcon.default)( /*#__PURE__*/React.createElement("path", {
  d: "M19 6h-2c0-2.76-2.24-5-5-5S7 3.24 7 6H5c-1.1 0-1.99.9-1.99 2L3 20c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-7-3c1.66 0 3 1.34 3 3H9c0-1.66 1.34-3 3-3zm0 10c-2.76 0-5-2.24-5-5h2c0 1.66 1.34 3 3 3s3-1.34 3-3h2c0 2.76-2.24 5-5 5z"
}), 'LocalMall');

exports.Z = _default;

/***/ }),

/***/ 4761:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ Item; }
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6610);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5991);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(379);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6070);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7608);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7294);
/* harmony import */ var react_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3253);
/* harmony import */ var react_modal__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_modal__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Lightbox__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(155);
/* harmony import */ var _material_ui_icons_ArrowBack__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9826);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5893);






var _br, _br2, _br3, _br4, _br5, _br6;

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }








var Item = /*#__PURE__*/function (_React$PureComponent) {
  (0,_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)(Item, _React$PureComponent);

  var _super = _createSuper(Item);

  function Item() {
    var _this;

    (0,_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z)(this, Item);

    _this = _super.call(this);
    _this.state = {
      showLightbox: false
    };
    return _this;
  }

  (0,_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z)(Item, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var language = window.language.modals.main.marketplace.product;

      if (!this.props.data.display_name) {
        return null;
      }

      var warningHTML;

      if (this.props.data.quote_api) {
        warningHTML = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("div", {
          className: "productInformation",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("ul", {
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("li", {
              className: "header",
              children: language.quote_warning.title
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("li", {
              id: "updated",
              children: language.quote_warning.description
            })]
          })
        });
      } // prevent console error


      var iconsrc = window.constants.DDG_PROXY + this.props.data.icon;

      if (!this.props.data.icon) {
        iconsrc = null;
      }

      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
        id: "item",
        children: [_br || (_br = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("br", {})), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(_material_ui_icons_ArrowBack__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
          className: "backArrow",
          onClick: this.props.toggleFunction
        }), _br2 || (_br2 = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("br", {})), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("h1", {
          children: this.props.data.display_name
        }), _br3 || (_br3 = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("br", {})), this.props.button, _br4 || (_br4 = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("br", {})), iconsrc ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("img", {
          alt: "product",
          draggable: "false",
          src: iconsrc,
          onClick: function onClick() {
            return _this2.setState({
              showLightbox: true
            });
          }
        }) : null, /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
          className: "informationContainer",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("h1", {
            className: "overview",
            children: language.overview
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("p", {
            className: "description",
            dangerouslySetInnerHTML: {
              __html: this.props.data.description
            }
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("div", {
            className: "productInformation",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("ul", {
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("li", {
                className: "header",
                children: language.version
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("li", {
                children: this.props.data.version
              }), _br5 || (_br5 = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("br", {})), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("li", {
                className: "header",
                children: language.author
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("li", {
                children: this.props.data.author
              })]
            })
          }), _br6 || (_br6 = /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("br", {})), warningHTML]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)((react_modal__WEBPACK_IMPORTED_MODULE_3___default()), {
          closeTimeoutMS: 100,
          onRequestClose: function onRequestClose() {
            return _this2.setState({
              showLightbox: false
            });
          },
          isOpen: this.state.showLightbox,
          className: "Modal lightboxmodal",
          overlayClassName: "Overlay resetoverlay",
          ariaHideApp: false,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)(_Lightbox__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
            modalClose: function modalClose() {
              return _this2.setState({
                showLightbox: false
              });
            },
            img: iconsrc
          })
        })]
      });
    }
  }]);

  return Item;
}(react__WEBPACK_IMPORTED_MODULE_2__.PureComponent);



/***/ }),

/***/ 2098:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ Items; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);


function Items(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
    className: "items",
    children: props.items.map(function (item) {
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "item",
        onClick: function onClick() {
          return props.toggleFunction(item.name);
        },
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
          alt: "icon",
          draggable: "false",
          src: window.constants.DDG_PROXY + item.icon_url
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "details",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", {
            children: item.display_name || item.name
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
            children: item.author
          })]
        })]
      }, item.name);
    })
  });
}

/***/ }),

/***/ 155:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ Lightbox; }
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);



function Lightbox(props) {
  window.analytics.postEvent('modal', 'Opened lightbox');
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
      className: "closeModal",
      onClick: props.modalClose,
      children: "\xD7"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
      src: props.img,
      className: "lightboximg",
      draggable: false,
      alt: "Item screenshot"
    })]
  });
}

/***/ }),

/***/ 6414:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ Dropdown; }
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6610);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5991);
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3349);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(379);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6070);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7608);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6156);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7294);
/* harmony import */ var _modules_helpers_eventbus__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9620);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5893);








function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }







var Dropdown = /*#__PURE__*/function (_React$PureComponent) {
  (0,_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z)(Dropdown, _React$PureComponent);

  var _super = _createSuper(Dropdown);

  function Dropdown(props) {
    var _this;

    (0,_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z)(this, Dropdown);

    _this = _super.call(this, props);

    (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)((0,_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z)(_this), "onChange", function (e) {
      var value = e.target.value;

      if (value === window.language.modals.main.loading) {
        return;
      }

      window.analytics.postEvent('setting', "".concat(_this.props.name, " from ").concat(_this.state.value, " to ").concat(value));

      _this.setState({
        value: value,
        title: e.target[e.target.selectedIndex].text
      });

      localStorage.setItem(_this.props.name, value);

      if (_this.props.onChange) {
        _this.props.onChange(value);
      }

      if (_this.props.element) {
        if (!document.querySelector(_this.props.element)) {
          document.querySelector('.reminder-info').style.display = 'block';
          return localStorage.setItem('showReminder', true);
        }
      }

      _modules_helpers_eventbus__WEBPACK_IMPORTED_MODULE_8__/* .default.dispatch */ .Z.dispatch('refresh', _this.props.category);
    });

    _this.state = {
      value: localStorage.getItem(_this.props.name) || '',
      title: ''
    };
    return _this;
  }

  (0,_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z)(Dropdown, [{
    key: "getLabel",
    value: function getLabel() {
      return this.props.label ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("label", {
        children: this.props.label
      }) : null;
    }
  }, {
    key: "componentDidMount",
    value: // todo: find a better way to do this
    function componentDidMount() {
      var element = document.getElementById(this.props.name);
      this.setState({
        title: element[element.selectedIndex].text
      });
    }
  }, {
    key: "render",
    value: function render() {
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
        children: [this.getLabel(), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("select", {
          id: this.props.name,
          value: this.state.value,
          onChange: this.onChange,
          style: {
            width: "".concat(8 * this.state.title.length + 50, "px")
          },
          children: this.props.children
        })]
      });
    }
  }]);

  return Dropdown;
}(react__WEBPACK_IMPORTED_MODULE_2__.PureComponent);



/***/ }),

/***/ 9469:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ FileUpload; }
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6610);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5991);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(379);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6070);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7608);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7294);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2132);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5893);






function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }





var FileUpload = /*#__PURE__*/function (_React$PureComponent) {
  (0,_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z)(FileUpload, _React$PureComponent);

  var _super = _createSuper(FileUpload);

  function FileUpload() {
    (0,_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z)(this, FileUpload);

    return _super.apply(this, arguments);
  }

  (0,_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z)(FileUpload, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this = this;

      document.getElementById(this.props.id).onchange = function (e) {
        var reader = new FileReader();
        var file = e.target.files[0];

        if (_this.props.type === 'settings') {
          reader.readAsText(file, 'UTF-8');
        } else {
          // background upload
          if (file.size > 2000000) {
            return (0,react_toastify__WEBPACK_IMPORTED_MODULE_7__/* .toast */ .Am)(window.language.modals.main.file_upload_error);
          }

          reader.readAsDataURL(file);
        }

        reader.addEventListener('load', function (e) {
          _this.props.loadFunction(e);
        });
      };
    }
  }, {
    key: "render",
    value: function render() {
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("input", {
        id: this.props.id,
        type: "file",
        style: {
          display: 'none'
        },
        accept: this.props.accept
      });
    }
  }]);

  return FileUpload;
}(react__WEBPACK_IMPORTED_MODULE_2__.PureComponent);



/***/ }),

/***/ 1843:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ Addons; }
});

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js
var classCallCheck = __webpack_require__(6610);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/createClass.js
var createClass = __webpack_require__(5991);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/inherits.js
var inherits = __webpack_require__(379);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js
var possibleConstructorReturn = __webpack_require__(6070);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js
var getPrototypeOf = __webpack_require__(7608);
// EXTERNAL MODULE: ./node_modules/react/index.js
var react = __webpack_require__(7294);
// EXTERNAL MODULE: ./node_modules/@material-ui/icons/LocalMall.js
var LocalMall = __webpack_require__(7826);
// EXTERNAL MODULE: ./src/components/modals/main/marketplace/Item.jsx
var Item = __webpack_require__(4761);
// EXTERNAL MODULE: ./src/components/modals/main/marketplace/Items.jsx
var Items = __webpack_require__(2098);
// EXTERNAL MODULE: ./src/components/modals/main/settings/Dropdown.jsx
var Dropdown = __webpack_require__(6414);
// EXTERNAL MODULE: ./src/modules/helpers/marketplace.js
var marketplace = __webpack_require__(2663);
// EXTERNAL MODULE: ./node_modules/react-toastify/dist/react-toastify.esm.js
var react_toastify_esm = __webpack_require__(2132);
// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
;// CONCATENATED MODULE: ./src/components/modals/main/marketplace/sections/Added.jsx






var _LocalMallIcon, _br;

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0,getPrototypeOf/* default */.Z)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0,getPrototypeOf/* default */.Z)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0,possibleConstructorReturn/* default */.Z)(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }












var Added = /*#__PURE__*/function (_React$PureComponent) {
  (0,inherits/* default */.Z)(Added, _React$PureComponent);

  var _super = _createSuper(Added);

  function Added() {
    var _this;

    (0,classCallCheck/* default */.Z)(this, Added);

    _this = _super.call(this);
    _this.state = {
      installed: JSON.parse(localStorage.getItem('installed')),
      item: {},
      button: ''
    };
    _this.buttons = {
      uninstall: /*#__PURE__*/(0,jsx_runtime.jsx)("button", {
        className: "removeFromMue",
        onClick: function onClick() {
          return _this.uninstall();
        },
        children: window.language.modals.main.marketplace.product.buttons.remove
      })
    };
    _this.language = window.language.modals.main.addons;
    return _this;
  }

  (0,createClass/* default */.Z)(Added, [{
    key: "toggle",
    value: function toggle(type, data) {
      if (type === 'item') {
        var installed = JSON.parse(localStorage.getItem('installed'));
        var info = installed.find(function (i) {
          return i.name === data;
        });
        this.setState({
          item: {
            type: info.type,
            name: data,
            display_name: info.name,
            author: info.author,
            description: marketplace/* default.urlParser */.Z.urlParser(info.description.replace(/\n/g, '<br>')),
            //updated: info.updated,
            version: info.version,
            icon: info.screenshot_url,
            quote_api: info.quote_api || null
          },
          button: this.buttons.uninstall
        });
        window.analytics.postEvent('marketplace', 'Item viewed');
      } else {
        this.setState({
          item: {}
        });
      }
    }
  }, {
    key: "uninstall",
    value: function uninstall() {
      marketplace/* default.uninstall */.Z.uninstall(this.state.item.type, this.state.item.display_name);
      (0,react_toastify_esm/* toast */.Am)(window.language.toasts.uninstalled);
      this.setState({
        button: '',
        installed: JSON.parse(localStorage.getItem('installed'))
      });
      window.analytics.postEvent('marketplace', 'Uninstall');
    }
  }, {
    key: "sortAddons",
    value: function sortAddons(value, sendEvent) {
      var installed = JSON.parse(localStorage.getItem('installed'));

      switch (value) {
        case 'newest':
          installed.reverse();
          break;

        case 'oldest':
          break;

        case 'a-z':
          installed.sort();
          break;

        case 'z-a':
          installed.sort();
          installed.reverse();
          break;

        default:
          break;
      }

      this.setState({
        installed: installed
      });

      if (sendEvent) {
        window.analytics.postEvent('marketplace', 'Sort');
      }
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      this.sortAddons(localStorage.getItem('sortAddons'), false);
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      if (this.state.installed.length === 0) {
        return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
          className: "emptyitems",
          children: /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
            className: "emptyMessage",
            children: [_LocalMallIcon || (_LocalMallIcon = /*#__PURE__*/(0,jsx_runtime.jsx)(LocalMall/* default */.Z, {})), /*#__PURE__*/(0,jsx_runtime.jsx)("h1", {
              children: this.language.empty.title
            }), /*#__PURE__*/(0,jsx_runtime.jsx)("p", {
              className: "description",
              children: this.language.empty.description
            })]
          })
        });
      }

      if (this.state.item.display_name) {
        return /*#__PURE__*/(0,jsx_runtime.jsx)(Item/* default */.Z, {
          data: this.state.item,
          button: this.state.button,
          toggleFunction: function toggleFunction() {
            return _this2.toggle();
          }
        });
      }

      return /*#__PURE__*/(0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [/*#__PURE__*/(0,jsx_runtime.jsxs)(Dropdown/* default */.Z, {
          label: this.language.sort.title,
          name: "sortAddons",
          onChange: function onChange(value) {
            return _this2.sortAddons(value);
          },
          children: [/*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "newest",
            children: this.language.sort.newest
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "oldest",
            children: this.language.sort.oldest
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "a-z",
            children: this.language.sort.a_z
          }), /*#__PURE__*/(0,jsx_runtime.jsx)("option", {
            value: "z-a",
            children: this.language.sort.z_a
          })]
        }), _br || (_br = /*#__PURE__*/(0,jsx_runtime.jsx)("br", {})), /*#__PURE__*/(0,jsx_runtime.jsx)(Items/* default */.Z, {
          items: this.state.installed,
          toggleFunction: function toggleFunction(input) {
            return _this2.toggle('item', input);
          }
        })]
      });
    }
  }]);

  return Added;
}(react.PureComponent);


// EXTERNAL MODULE: ./src/components/modals/main/settings/FileUpload.jsx
var FileUpload = __webpack_require__(9469);
;// CONCATENATED MODULE: ./src/components/modals/main/marketplace/sections/Sideload.jsx
var Sideload_LocalMallIcon;







function Sideload() {
  var install = function install(input) {
    marketplace/* default.install */.Z.install(input.type, input);
    (0,react_toastify_esm/* toast */.Am)(window.language.toasts.installed);
    window.analytics.postEvent('marketplace', 'Sideload');
  };

  return /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
    className: "emptyitems",
    children: /*#__PURE__*/(0,jsx_runtime.jsxs)("div", {
      className: "emptyMessage",
      children: [/*#__PURE__*/(0,jsx_runtime.jsx)(FileUpload/* default */.Z, {
        id: "file-input",
        type: "settings",
        accept: "application/json",
        loadFunction: function loadFunction(e) {
          return install(JSON.parse(e.target.result));
        }
      }), Sideload_LocalMallIcon || (Sideload_LocalMallIcon = /*#__PURE__*/(0,jsx_runtime.jsx)(LocalMall/* default */.Z, {})), /*#__PURE__*/(0,jsx_runtime.jsx)("h1", {
        children: window.language.modals.main.addons.sideload
      }), /*#__PURE__*/(0,jsx_runtime.jsx)("button", {
        className: "addToMue sideload",
        onClick: function onClick() {
          return document.getElementById('file-input').click();
        },
        children: window.language.modals.main.settings.sections.background.source.upload
      })]
    })
  });
}
// EXTERNAL MODULE: ./src/components/modals/main/tabs/backend/Tabs.jsx + 2 modules
var Tabs = __webpack_require__(9027);
;// CONCATENATED MODULE: ./src/components/modals/main/tabs/Addons.jsx
var _Added, _Sideload;






function Addons() {
  var addons = window.language.modals.main.addons;
  return /*#__PURE__*/(0,jsx_runtime.jsxs)(Tabs/* default */.Z, {
    children: [/*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      label: addons.added,
      children: _Added || (_Added = /*#__PURE__*/(0,jsx_runtime.jsx)(Added, {}))
    }), /*#__PURE__*/(0,jsx_runtime.jsx)("div", {
      label: addons.sideload,
      children: _Sideload || (_Sideload = /*#__PURE__*/(0,jsx_runtime.jsx)(Sideload, {}))
    })]
  });
}

/***/ }),

/***/ 2663:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": function() { return /* binding */ MarketplaceFunctions; }
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6610);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5991);
/* harmony import */ var _eventbus__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9620);




var MarketplaceFunctions = /*#__PURE__*/function () {
  function MarketplaceFunctions() {
    (0,_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z)(this, MarketplaceFunctions);
  }

  (0,_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z)(MarketplaceFunctions, null, [{
    key: "urlParser",
    value: // based on https://stackoverflow.com/questions/37684/how-to-replace-plain-urls-with-links
    function urlParser(input) {
      var urlPattern = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()!@:%_+.~#?&//=]*)/;
      return input.replace(urlPattern, '<a href="$&" target="_blank">$&</a>');
    }
  }, {
    key: "uninstall",
    value: function uninstall(type, name) {
      switch (type) {
        case 'settings':
          var oldSettings = JSON.parse(localStorage.getItem('backup_settings'));
          localStorage.clear();
          oldSettings.forEach(function (item) {
            localStorage.setItem(item.name, item.value);
          });
          break;

        case 'quotes':
          localStorage.removeItem('quote_packs');
          localStorage.removeItem('quoteAPI');
          localStorage.setItem('quoteType', localStorage.getItem('oldQuoteType'));
          localStorage.removeItem('oldQuoteType');
          _eventbus__WEBPACK_IMPORTED_MODULE_2__/* .default.dispatch */ .Z.dispatch('refresh', 'marketplacequoteuninstall');
          break;

        case 'photos':
          localStorage.removeItem('photo_packs');
          localStorage.setItem('backgroundType', localStorage.getItem('oldBackgroundType'));
          localStorage.removeItem('oldBackgroundType');
          _eventbus__WEBPACK_IMPORTED_MODULE_2__/* .default.dispatch */ .Z.dispatch('refresh', 'marketplacebackgrounduninstall');
          break;

        default:
          break;
      }

      var installed = JSON.parse(localStorage.getItem('installed'));

      for (var i = 0; i < installed.length; i++) {
        if (installed[i].name === name) {
          installed.splice(i, 1);
          break;
        }
      }

      localStorage.setItem('installed', JSON.stringify(installed));
    }
  }, {
    key: "install",
    value: function install(type, input, sideload) {
      switch (type) {
        case 'settings':
          localStorage.removeItem('backup_settings');
          var oldSettings = [];
          Object.keys(localStorage).forEach(function (key) {
            oldSettings.push({
              name: key,
              value: localStorage.getItem(key)
            });
          });
          localStorage.setItem('backup_settings', JSON.stringify(oldSettings));
          Object.keys(input.settings).forEach(function (key) {
            localStorage.setItem(key, input.settings[key]);
          });
          break;

        case 'photos':
          localStorage.setItem('photo_packs', JSON.stringify(input.photos));
          localStorage.setItem('oldBackgroundType', localStorage.getItem('backgroundType'));
          localStorage.setItem('backgroundType', 'photo_pack');
          _eventbus__WEBPACK_IMPORTED_MODULE_2__/* .default.dispatch */ .Z.dispatch('refresh', 'background');
          break;

        case 'quotes':
          if (input.quote_api) {
            localStorage.setItem('quoteAPI', JSON.stringify(input.quote_api));
          }

          localStorage.setItem('quote_packs', JSON.stringify(input.quotes));
          localStorage.setItem('oldQuoteType', localStorage.getItem('quoteType'));
          localStorage.setItem('quoteType', 'quote_pack');
          _eventbus__WEBPACK_IMPORTED_MODULE_2__/* .default.dispatch */ .Z.dispatch('refresh', 'quote');
          break;

        default:
          break;
      }

      var installed = JSON.parse(localStorage.getItem('installed'));

      if (sideload) {
        installed.push({
          content: {
            updated: 'Unpublished',
            data: input
          }
        });
      } else {
        installed.push(input);
      }

      localStorage.setItem('installed', JSON.stringify(installed));
    }
  }]);

  return MarketplaceFunctions;
}();



/***/ })

}]);